package com.spas.logic;

import com.spas.models.Student;

public class RiskEngine {
    
    public static class RiskProfile {
        public Student student;
        public String riskLevel; // High, Medium, Low
        public int failedSubjectsCount;
        public double attendanceDrop;
        
        public RiskProfile(Student student, String riskLevel, int failed, double attDrop) {
            this.student = student;
            this.riskLevel = riskLevel;
            this.failedSubjectsCount = failed;
            this.attendanceDrop = attDrop;
        }
    }
    
    public static RiskProfile assessStudentRisk(Student student, int failedCount, double attendancePct) {
        String level = "Low";
        
        if (failedCount >= 3 || attendancePct < 60.0) {
            level = "High";
        } else if (failedCount >= 1 || attendancePct < 75.0) {
            level = "Medium";
        }
        
        return new RiskProfile(student, level, failedCount, 100 - attendancePct);
    }
}

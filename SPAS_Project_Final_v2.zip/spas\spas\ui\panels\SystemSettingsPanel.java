package com.spas.ui.panels;

import com.spas.auth.SessionManager;
import com.spas.db.DBManager;
import com.spas.models.User;
import com.spas.ui.theme.ThemeManager;
import com.spas.validation.Validator;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemSettingsPanel extends JPanel {
    private JPasswordField currentPassword;
    private JPasswordField newPassword;
    private JTextField semesterField;
    private JComboBox<String> themeCombo;

    public SystemSettingsPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("System Settings");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        
        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Updated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);
        
        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        
        JPanel settingsPanel = new JPanel();
        settingsPanel.setLayout(new BoxLayout(settingsPanel, BoxLayout.Y_AXIS));
        settingsPanel.add(createThemeCard());
        settingsPanel.add(Box.createVerticalStrut(12));
        settingsPanel.add(createPasswordCard());
        settingsPanel.add(Box.createVerticalStrut(12));
        settingsPanel.add(createBackupCard());
        settingsPanel.add(Box.createVerticalStrut(12));
        settingsPanel.add(createPreferencesCard());
        settingsPanel.add(Box.createVerticalStrut(12));
        settingsPanel.add(createInfoCard());
        
        content.add(settingsPanel, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createThemeCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createTitledBorder("Theme Settings"));
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        themeCombo = new JComboBox<>(new String[]{"Light", "Dark"});
        themeCombo.setSelectedItem(ThemeManager.isDarkMode() ? "Dark" : "Light");
        JButton apply = createStyledButton("Apply Theme", new Color(47, 93, 255));
        apply.addActionListener(e -> {
            boolean wantsDark = "Dark".equals(themeCombo.getSelectedItem());
            if (wantsDark != ThemeManager.isDarkMode()) {
                ThemeManager.toggleTheme();
            }
        });
        
        controls.add(new JLabel("Theme:"));
        controls.add(themeCombo);
        controls.add(apply);
        
        card.add(controls, BorderLayout.CENTER);
        return card;
    }

    private JPanel createPasswordCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createTitledBorder("Change Password"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        currentPassword = new JPasswordField(15);
        newPassword = new JPasswordField(15);
        JButton change = createStyledButton("Change Password", new Color(25, 145, 85));
        change.addActionListener(e -> changePassword());
        
        controls.add(new JLabel("Current:"));
        controls.add(currentPassword);
        controls.add(new JLabel("New:"));
        controls.add(newPassword);
        controls.add(change);
        
        card.add(controls, BorderLayout.CENTER);
        return card;
    }

    private JPanel createBackupCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createTitledBorder("Database Backup"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        JButton backup = createStyledButton("Backup schema.sql", new Color(220, 53, 69));
        JButton restore = createStyledButton("Restore Instructions", new Color(108, 117, 125));
        backup.addActionListener(e -> backupSchemaFile());
        restore.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "To restore the database, open phpMyAdmin, select spas_db, and import schema.sql or your exported SQL backup."));
        
        controls.add(backup);
        controls.add(restore);
        
        card.add(controls, BorderLayout.CENTER);
        return card;
    }

    private JPanel createPreferencesCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createTitledBorder("System Preferences"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        semesterField = new JTextField("1", 5);
        JButton save = createStyledButton("Save Semester", new Color(255, 165, 0));
        save.addActionListener(e -> savePreference("active_semester", semesterField.getText().trim()));
        
        controls.add(new JLabel("Active Semester:"));
        controls.add(semesterField);
        controls.add(save);
        
        card.add(controls, BorderLayout.CENTER);
        return card;
    }

    private JPanel createInfoCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createTitledBorder("Application Information"));
        
        JLabel info = new JLabel("<html><b>SPAS Version 1.0</b> | Java Swing + MySQL | Final Year Project<br>Student Performance Analysis System</html>");
        info.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        card.add(info, BorderLayout.CENTER);
        return card;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));
        
        JLabel statusLabel = new JLabel("Ready | Modify settings and click apply to save changes");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        
        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Settings Module"), BorderLayout.EAST);
        
        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(160, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void changePassword() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user == null) {
            JOptionPane.showMessageDialog(this, "Login session not found.");
            return;
        }
        String current = new String(currentPassword.getPassword());
        String next = new String(newPassword.getPassword());
        if (!BCrypt.checkpw(current, user.getPasswordHash())) {
            JOptionPane.showMessageDialog(this, "Current password is incorrect.");
            return;
        }
        if (!Validator.isValidPassword(next)) {
            JOptionPane.showMessageDialog(this, "New password must be at least 8 characters and include an uppercase letter and a digit.");
            return;
        }
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try (PreparedStatement stmt = conn.prepareStatement("UPDATE users SET password_hash=? WHERE user_id=?")) {
            stmt.setString(1, BCrypt.hashpw(next, BCrypt.gensalt()));
            stmt.setInt(2, user.getUserId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Password changed successfully. Please login again later with the new password.");
            currentPassword.setText("");
            newPassword.setText("");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not change password: " + e.getMessage());
        }
    }

    private void backupSchemaFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("schema-backup.sql"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            Files.copy(new File("schema.sql").toPath(), chooser.getSelectedFile().toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            JOptionPane.showMessageDialog(this, "Schema backup saved.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Backup failed: " + e.getMessage());
        }
    }

    private void savePreference(String key, String value) {
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO system_preferences (pref_key, pref_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE pref_value=?")) {
            stmt.setString(1, key);
            stmt.setString(2, value);
            stmt.setString(3, value);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Preference saved.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not save preference: " + e.getMessage());
        }
    }
}

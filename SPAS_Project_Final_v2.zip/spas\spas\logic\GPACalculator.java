package com.spas.logic;

import com.spas.models.Marks;
import com.spas.models.Subject;
import java.util.List;

public class GPACalculator {
    
    public static double calculateGPA(List<Marks> marksList, List<Subject> subjectList) {
        if (marksList == null || marksList.isEmpty()) return 0.0;
        
        // CS-201 Requirement: Processing via arrays
        double[] weightedScores = new double[marksList.size()];
        double[] creditHours = new double[marksList.size()];
        
        for (int i = 0; i < marksList.size(); i++) {
            Marks m = marksList.get(i);
            Subject s = getSubject(subjectList, m.getSubjectId());
            if (s != null) {
                creditHours[i] = s.getCreditHours();
                weightedScores[i] = getGradePoint(m.getTotal()) * s.getCreditHours();
            }
        }
        
        double totalPoints = 0;
        double totalCredits = 0;
        for (int i = 0; i < weightedScores.length; i++) {
            totalPoints += weightedScores[i];
            totalCredits += creditHours[i];
        }
        
        if (totalCredits == 0) return 0.0;
        return totalPoints / totalCredits;
    }

    private static Subject getSubject(List<Subject> subjects, int subjectId) {
        for (Subject s : subjects) {
            if (s.getSubjectId() == subjectId) return s;
        }
        return null;
    }

    private static double getGradePoint(double totalMarks) {
        if (totalMarks >= 85) return 4.0;
        if (totalMarks >= 80) return 3.7;
        if (totalMarks >= 75) return 3.3;
        if (totalMarks >= 70) return 3.0;
        if (totalMarks >= 65) return 2.7;
        if (totalMarks >= 60) return 2.3;
        if (totalMarks >= 55) return 2.0;
        if (totalMarks >= 50) return 1.7;
        return 0.0; // Fail
    }
}

package com.spas.ui;

import com.spas.auth.LoginFrame;
import com.spas.auth.SessionManager;
import com.spas.models.User;
import com.spas.ui.theme.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class BaseDashboard extends JFrame {
    protected JPanel contentPanel;
    protected CardLayout cardLayout;
    protected JPanel sidebar;
    private Map<String, JPanel> cards = new LinkedHashMap<>();
    private JButton selectedButton;

    public BaseDashboard(String title) {
        setTitle("SPAS - " + title);
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initLayout();
        setupSidebar();
    }

    private void initLayout() {
        setLayout(new BorderLayout());

        // Top Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        User user = SessionManager.getInstance().getCurrentUser();
        JLabel userLabel = new JLabel("Logged in as: " + (user != null ? user.getFullName() + " (" + user.getRole() + ")" : "Unknown"));
        topBar.add(userLabel, BorderLayout.WEST);

        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton themeBtn = new JButton(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
        themeBtn.setFocusPainted(false);
        themeBtn.addActionListener(e -> {
            ThemeManager.toggleTheme();
            themeBtn.setText(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
        });

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            SessionManager.getInstance().logout();
            this.dispose();
            new LoginFrame().setVisible(true);
        });

        rightTop.add(themeBtn);
        rightTop.add(logoutBtn);
        topBar.add(rightTop, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // Sidebar
        sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        sidebar.setBackground(new Color(245, 247, 252));
        
        // Add a scroll pane to sidebar if many items
        JScrollPane sidebarScroll = new JScrollPane(sidebar);
        sidebarScroll.setBorder(null);
        add(sidebarScroll, BorderLayout.WEST);

        // Content Area
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(contentPanel, BorderLayout.CENTER);
    }

    protected void addSidebarItem(String title, JPanel panel) {
        cards.put(title, panel);
        contentPanel.add(panel, title);

        JButton btn = new JButton(title);
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setToolTipText(title);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        
        btn.addActionListener(e -> {
            cardLayout.show(contentPanel, title);
            setSelectedSidebarButton(btn);
        });

        sidebar.add(btn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
    }

    private void setSelectedSidebarButton(JButton btn) {
        if (selectedButton != null) {
            selectedButton.setBackground(UIManager.getColor("Button.background"));
            selectedButton.setForeground(UIManager.getColor("Button.foreground"));
        }
        selectedButton = btn;
        selectedButton.setBackground(new Color(47, 93, 255));
        selectedButton.setForeground(Color.WHITE);
    }
    
    protected abstract void setupSidebar();
}

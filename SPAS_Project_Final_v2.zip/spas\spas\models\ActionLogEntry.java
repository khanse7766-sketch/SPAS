package com.spas.models;

import java.sql.Timestamp;

/**
 * Model class for an action log entry, used by the UndoStack.
 */
public class ActionLogEntry {
    private int logId;
    private String actionType; // INSERT, UPDATE, DELETE
    private String tableName;
    private int recordId;
    private String oldValue; // JSON or stringified representation
    private String newValue;
    private int performedBy;
    private Timestamp performedAt;
    private boolean reversed;

    public ActionLogEntry(int logId, String actionType, String tableName, int recordId, String oldValue, String newValue, int performedBy, Timestamp performedAt, boolean reversed) {
        this.logId = logId;
        this.actionType = actionType;
        this.tableName = tableName;
        this.recordId = recordId;
        this.oldValue = oldValue;
        this.newValue = newValue;
        this.performedBy = performedBy;
        this.performedAt = performedAt;
        this.reversed = reversed;
    }

    public int getLogId() { return logId; }
    public String getActionType() { return actionType; }
    public String getTableName() { return tableName; }
    public int getRecordId() { return recordId; }
    public String getOldValue() { return oldValue; }
    public String getNewValue() { return newValue; }
    public int getPerformedBy() { return performedBy; }
    public Timestamp getPerformedAt() { return performedAt; }
    public boolean isReversed() { return reversed; }
    
    public void setReversed(boolean reversed) { this.reversed = reversed; }
}

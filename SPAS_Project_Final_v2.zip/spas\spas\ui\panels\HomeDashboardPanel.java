package com.spas.ui.panels;

import com.spas.auth.SessionManager;
import com.spas.db.DBManager;
import com.spas.models.User;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HomeDashboardPanel extends JPanel {
    private JLabel clockLabel;
    private JPanel cardsPanel;
    private JPanel chartsPanel;
    private DefaultListModel<String> activityModel;
    private DefaultListModel<String> notificationModel;

    public HomeDashboardPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));
        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);
        loadDashboardData();
        new Timer(1000, e -> updateClock()).start();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("SPAS - Student Performance Analysis System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        User user = SessionManager.getInstance().getCurrentUser();
        JLabel userLabel = new JLabel((user == null ? "Guest" : user.getFullName()) + " | " + (user == null ? "N/A" : user.getRole()));
        clockLabel = new JLabel();
        updateClock();

        JPanel right = new JPanel(new GridLayout(2, 1));
        right.add(userLabel);
        right.add(clockLabel);
        header.add(title, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        cardsPanel = new JPanel(new GridLayout(0, 4, 10, 10));
        chartsPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        content.add(cardsPanel, BorderLayout.NORTH);
        content.add(chartsPanel, BorderLayout.CENTER);
        content.add(createBottomInfo(), BorderLayout.SOUTH);
        return new JScrollPane(content);
    }

    private JPanel createBottomInfo() {
        JPanel bottom = new JPanel(new GridLayout(1, 3, 10, 10));
        JPanel actions = boxed("Quick Actions");
        String[] actionNames = {"Add Student", "Add Subject", "Enter Marks", "Take Attendance", "Generate Ranking", "Generate Reports"};
        for (String name : actionNames) {
            JButton button = new JButton(name);
            button.setFocusPainted(false);
            actions.add(button);
        }

        JPanel activities = boxed("Recent Activities");
        activityModel = new DefaultListModel<>();
        activities.add(new JScrollPane(new JList<>(activityModel)));

        JPanel notifications = boxed("Notifications");
        notificationModel = new DefaultListModel<>();
        notifications.add(new JScrollPane(new JList<>(notificationModel)));

        bottom.add(actions);
        bottom.add(activities);
        bottom.add(notifications);
        return bottom;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        User user = SessionManager.getInstance().getCurrentUser();
        footer.add(new JLabel("Version 1.0 | Database: MySQL | Logged User: " + (user == null ? "Guest" : user.getFullName())), BorderLayout.WEST);
        footer.add(new JLabel("Copyright 2026 SPAS"), BorderLayout.EAST);
        return footer;
    }

    private JPanel boxed(String title) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(title),
                new EmptyBorder(8, 8, 8, 8)
        ));
        return panel;
    }

    private void loadDashboardData() {
        cardsPanel.removeAll();
        chartsPanel.removeAll();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            addCard("Database", "Offline", "Start MySQL/XAMPP", new Color(180, 60, 60));
            return;
        }

        try {
            int students = count(conn, "students");
            int subjects = count(conn, "subjects");
            int faculty = countWhere(conn, "users", "role='TEACHER'");
            int attendance = count(conn, "attendance");
            double avgAttendance = scalarDouble(conn, "SELECT COALESCE(AVG(status='PRESENT') * 100, 0) FROM attendance");
            double avgGpa = scalarDouble(conn, "SELECT COALESCE(AVG(gpa), 0) FROM semester_summary");
            double highGpa = scalarDouble(conn, "SELECT COALESCE(MAX(gpa), 0) FROM semester_summary");
            double lowGpa = scalarDouble(conn, "SELECT COALESCE(MIN(gpa), 0) FROM semester_summary");
            int passed = countPassed(conn);
            int failed = countFailed(conn);
            int atRisk = countAtRisk(conn);

            addCard("Students", String.valueOf(students), "Total registered students", new Color(47, 93, 255));
            addCard("Subjects", String.valueOf(subjects), "Active subjects", new Color(0, 140, 120));
            addCard("Faculty", String.valueOf(faculty), "Teacher accounts", new Color(130, 90, 180));
            addCard("Classes", String.valueOf(subjects), "Subject classes", new Color(220, 125, 35));
            addCard("Attendance", String.valueOf(attendance), "Recorded entries", new Color(30, 150, 90));
            addCard("Avg Attendance", round(avgAttendance) + "%", "Present percentage", new Color(60, 120, 170));
            addCard("Avg GPA", String.valueOf(round(avgGpa)), "Class average", new Color(90, 150, 70));
            addCard("Highest GPA", String.valueOf(round(highGpa)), "Best performance", new Color(40, 130, 90));
            addCard("Lowest GPA", String.valueOf(round(lowGpa)), "Needs attention", new Color(200, 90, 55));
            addCard("Passed", String.valueOf(passed), "GPA >= 2.0", new Color(25, 145, 85));
            addCard("Failed", String.valueOf(failed), "GPA < 2.0", new Color(190, 70, 60));
            addCard("At Risk", String.valueOf(atRisk), "Low GPA or attendance", new Color(180, 90, 40));

            chartsPanel.add(new ChartPanel(createPassFailChart(passed, failed)));
            chartsPanel.add(new ChartPanel(createSemesterChart(conn)));
            loadActivities(conn);
            loadNotifications(avgAttendance, atRisk);
        } catch (SQLException e) {
            addCard("Dashboard Error", "!", e.getMessage(), new Color(180, 60, 60));
        }
        revalidate();
        repaint();
    }

    private void addCard(String title, String value, String detail, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        JLabel detailLabel = new JLabel(detail);
        detailLabel.setForeground(Color.WHITE);
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(detailLabel, BorderLayout.SOUTH);
        cardsPanel.add(card);
    }

    private JFreeChart createPassFailChart(int passed, int failed) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Passed", passed);
        dataset.setValue("Failed", failed);
        return ChartFactory.createPieChart("Pass vs Fail", dataset, true, true, false);
    }

    private JFreeChart createSemesterChart(Connection conn) throws SQLException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String q = "SELECT semester, COALESCE(AVG(gpa), 0) avg_gpa FROM semester_summary GROUP BY semester ORDER BY semester";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getDouble("avg_gpa"), "GPA", "Sem " + rs.getInt("semester"));
            }
        }
        return ChartFactory.createLineChart("Semester Performance", "Semester", "Average GPA", dataset);
    }

    private void loadActivities(Connection conn) throws SQLException {
        activityModel.clear();
        String q = "SELECT action_type, table_name, performed_at FROM action_log ORDER BY performed_at DESC LIMIT 8";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                activityModel.addElement(rs.getString("action_type") + " on " + rs.getString("table_name") + " at " + rs.getTimestamp("performed_at"));
            }
        }
        if (activityModel.isEmpty()) activityModel.addElement("No recent activities yet.");
    }

    private void loadNotifications(double avgAttendance, int atRisk) {
        notificationModel.clear();
        if (avgAttendance < 75) notificationModel.addElement("Average attendance is below 75%.");
        if (atRisk > 0) notificationModel.addElement(atRisk + " student(s) need attention.");
        notificationModel.addElement("Backup the database before major changes.");
    }

    private int count(Connection conn, String table) throws SQLException {
        return (int) scalarDouble(conn, "SELECT COUNT(*) FROM " + table);
    }

    private int countWhere(Connection conn, String table, String where) throws SQLException {
        return (int) scalarDouble(conn, "SELECT COUNT(*) FROM " + table + " WHERE " + where);
    }

    private int countPassed(Connection conn) throws SQLException {
        return (int) scalarDouble(conn, "SELECT COUNT(*) FROM semester_summary WHERE gpa >= 2.0");
    }

    private int countFailed(Connection conn) throws SQLException {
        return (int) scalarDouble(conn, "SELECT COUNT(*) FROM semester_summary WHERE gpa < 2.0");
    }

    private int countAtRisk(Connection conn) throws SQLException {
        String q = "SELECT COUNT(*) FROM students s WHERE " +
                "COALESCE((SELECT AVG(gpa) FROM semester_summary ss WHERE ss.student_id=s.student_id), 4) < 2.0 " +
                "OR COALESCE((SELECT AVG(status='PRESENT')*100 FROM attendance a WHERE a.student_id=s.student_id), 100) < 75";
        return (int) scalarDouble(conn, q);
    }

    private double scalarDouble(Connection conn, String query) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            return rs.next() ? rs.getDouble(1) : 0;
        }
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private void updateClock() {
        clockLabel.setText(new SimpleDateFormat("EEE, dd MMM yyyy | hh:mm:ss a").format(new Date()));
    }
}

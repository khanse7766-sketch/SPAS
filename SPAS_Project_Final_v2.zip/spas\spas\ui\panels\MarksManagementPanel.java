package com.spas.ui.panels;

import com.spas.auth.SessionManager;
import com.spas.datastructures.UndoStack;
import com.spas.db.DBManager;
import com.spas.models.ActionLogEntry;
import com.spas.models.User;
import com.spas.validation.Validator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MarksManagementPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JComboBox<String> subjectCombo;
    private JSpinner semesterSpinner;
    private JButton undoBtn;
    private JLabel avgTotalLabel;
    private JLabel avgQuizLabel;
    private JLabel avgAssignmentLabel;
    private JLabel avgMidtermLabel;
    private JLabel avgFinalLabel;
    private JLabel passRateLabel;
    private JLabel failRateLabel;

    public MarksManagementPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        loadSubjects();
        updateUndoButtonState();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Marks Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        
        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Date: " + new SimpleDateFormat("EEE, dd MMM yyyy").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);
        
        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createControlPanel(), BorderLayout.NORTH);
        topPanel.add(createStatisticsCards(), BorderLayout.CENTER);
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, createMarksTablePanel());
        splitPane.setResizeWeight(0.35);
        
        content.add(splitPane, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createTitledBorder("Marks Controls"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        
        semesterSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 8, 1));
        subjectCombo = new JComboBox<>();
        
        JButton loadBtn = createStyledButton("Load Students", new Color(47, 93, 255));
        JButton saveBtn = createStyledButton("Save Marks", new Color(25, 145, 85));
        JButton deleteBtn = createStyledButton("Delete Selected", new Color(220, 53, 69));
        undoBtn = createStyledButton("Undo Last Add", new Color(255, 165, 0));
        JButton refreshBtn = createStyledButton("Refresh", new Color(13, 110, 253));
        
        loadBtn.addActionListener(e -> loadMarks());
        saveBtn.addActionListener(e -> saveChanges());
        deleteBtn.addActionListener(e -> deleteSelectedMark());
        undoBtn.addActionListener(e -> performUndo());
        refreshBtn.addActionListener(e -> loadMarks());
        
        controls.add(new JLabel("Semester:"));
        controls.add(semesterSpinner);
        controls.add(new JLabel("Subject:"));
        controls.add(subjectCombo);
        controls.add(Box.createHorizontalStrut(10));
        controls.add(loadBtn);
        controls.add(saveBtn);
        controls.add(deleteBtn);
        controls.add(undoBtn);
        controls.add(refreshBtn);
        
        panel.add(controls, BorderLayout.CENTER);
        
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchField = new JTextField(15);
        JButton searchBtn = createStyledButton("Search Student", new Color(13, 202, 240));
        searchBtn.addActionListener(e -> searchStudent(searchField.getText().trim()));
        searchPanel.add(new JLabel("Search by Roll No:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        
        panel.add(searchPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private JPanel createStatisticsCards() {
        JPanel cardsPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        
        avgTotalLabel = createStatCard("Avg Total", "0", new Color(47, 93, 255));
        avgQuizLabel = createStatCard("Avg Quiz", "0", new Color(25, 145, 85));
        avgAssignmentLabel = createStatCard("Avg Assignment", "0", new Color(13, 110, 253));
        avgMidtermLabel = createStatCard("Avg Midterm", "0", new Color(255, 165, 0));
        avgFinalLabel = createStatCard("Avg Final", "0", new Color(220, 53, 69));
        passRateLabel = createStatCard("Pass Rate", "0%", new Color(25, 145, 85));
        failRateLabel = createStatCard("Fail Rate", "0%", new Color(220, 53, 69));
        JLabel totalStudentsLabel = createStatCard("Total Students", "0", new Color(108, 117, 125));
        
        cardsPanel.add(avgTotalLabel);
        cardsPanel.add(avgQuizLabel);
        cardsPanel.add(avgAssignmentLabel);
        cardsPanel.add(avgMidtermLabel);
        cardsPanel.add(avgFinalLabel);
        cardsPanel.add(passRateLabel);
        cardsPanel.add(failRateLabel);
        cardsPanel.add(totalStudentsLabel);
        
        return cardsPanel;
    }

    private JLabel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        JLabel wrapper = new JLabel();
        wrapper.setLayout(new BorderLayout());
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createMarksTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Marks Entry"));
        
        String[] cols = {"Mark ID", "Student ID", "Roll No", "Name", "Quiz (10)", "Assignment (15)", "Midterm (30)", "Final Exam (45)", "Total", "Grade", "GPA"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column >= 4 && column <= 7;
            }
        };
        
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column >= 8 && column <= 10 && !isSelected) {
                    if (column == 9) {
                        String grade = value.toString();
                        if (grade.startsWith("A")) {
                            c.setForeground(new Color(25, 145, 85));
                        } else if (grade.startsWith("B")) {
                            c.setForeground(new Color(13, 110, 253));
                        } else if (grade.startsWith("C")) {
                            c.setForeground(new Color(255, 165, 0));
                        } else if (grade.equals("F")) {
                            c.setForeground(new Color(220, 53, 69));
                        }
                    } else if (column == 10) {
                        double gpa = parseDouble(value);
                        if (gpa >= 3.0) {
                            c.setForeground(new Color(25, 145, 85));
                        } else if (gpa >= 2.0) {
                            c.setForeground(new Color(255, 165, 0));
                        } else {
                            c.setForeground(new Color(220, 53, 69));
                        }
                    }
                }
                return c;
            }
        });
        
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        legendPanel.add(new JLabel("Grade Colors: "));
        JLabel aLabel = createLegendLabel("A", new Color(25, 145, 85));
        JLabel bLabel = createLegendLabel("B", new Color(13, 110, 253));
        JLabel cLabel = createLegendLabel("C", new Color(255, 165, 0));
        JLabel fLabel = createLegendLabel("F", new Color(220, 53, 69));
        legendPanel.add(aLabel);
        legendPanel.add(bLabel);
        legendPanel.add(cLabel);
        legendPanel.add(fLabel);
        
        panel.add(legendPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private JLabel createLegendLabel(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setForeground(color);
        label.setFont(new Font("Segoe UI", Font.BOLD, 11));
        return label;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));
        
        JLabel statusLabel = new JLabel("Ready | Select semester and subject to load students");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        
        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Marks Module"), BorderLayout.EAST);
        
        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(140, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void loadSubjects() {
        subjectCombo.removeAllItems();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        String q = "SELECT subject_id, subject_code, name, semester FROM subjects ORDER BY semester, subject_code";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                subjectCombo.addItem(rs.getInt("subject_id") + " - " + rs.getString("subject_code") + 
                                    " - " + rs.getString("name") + " (Sem " + rs.getInt("semester") + ")");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load subjects: " + e.getMessage());
        }
    }

    private void loadMarks() {
        if (subjectCombo.getSelectedItem() == null) return;
        int subjectId = selectedSubjectId();
        int semester = (Integer) semesterSpinner.getValue();
        tableModel.setRowCount(0);

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String q = "SELECT m.mark_id, s.student_id, s.roll_no, u.full_name, m.quiz, m.assignment, m.midterm, m.final_exam " +
                "FROM students s JOIN users u ON s.user_id = u.user_id " +
                "LEFT JOIN marks m ON s.student_id = m.student_id AND m.subject_id = ? AND m.semester = ? " +
                "WHERE s.current_semester = ? ORDER BY s.roll_no";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setInt(1, subjectId);
            stmt.setInt(2, semester);
            stmt.setInt(3, semester);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    double quiz = rs.getDouble("quiz");
                    double assignment = rs.getDouble("assignment");
                    double midterm = rs.getDouble("midterm");
                    double finalExam = rs.getDouble("final_exam");
                    addMarksRow(rs.getObject("mark_id"), rs.getInt("student_id"), rs.getString("roll_no"),
                            rs.getString("full_name"), quiz, assignment, midterm, finalExam);
                }
            }
            updateStatistics();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load marks: " + e.getMessage());
        }
        updateUndoButtonState();
    }

    private void updateStatistics() {
        double totalQuiz = 0, totalAssignment = 0, totalMidterm = 0, totalFinal = 0, totalMarks = 0;
        int passCount = 0, failCount = 0;
        int rowCount = tableModel.getRowCount();
        
        for (int i = 0; i < rowCount; i++) {
            totalQuiz += parseDouble(tableModel.getValueAt(i, 4));
            totalAssignment += parseDouble(tableModel.getValueAt(i, 5));
            totalMidterm += parseDouble(tableModel.getValueAt(i, 6));
            totalFinal += parseDouble(tableModel.getValueAt(i, 7));
            totalMarks += parseDouble(tableModel.getValueAt(i, 8));
            
            String grade = tableModel.getValueAt(i, 9).toString();
            if (!grade.equals("F")) {
                passCount++;
            } else {
                failCount++;
            }
        }
        
        double avgQuiz = rowCount > 0 ? totalQuiz / rowCount : 0;
        double avgAssignment = rowCount > 0 ? totalAssignment / rowCount : 0;
        double avgMidterm = rowCount > 0 ? totalMidterm / rowCount : 0;
        double avgFinal = rowCount > 0 ? totalFinal / rowCount : 0;
        double avgTotal = rowCount > 0 ? totalMarks / rowCount : 0;
        double passRate = rowCount > 0 ? (passCount * 100.0 / rowCount) : 0;
        double failRate = rowCount > 0 ? (failCount * 100.0 / rowCount) : 0;
        
        updateStatLabel(avgTotalLabel, String.format("%.1f", avgTotal));
        updateStatLabel(avgQuizLabel, String.format("%.1f", avgQuiz));
        updateStatLabel(avgAssignmentLabel, String.format("%.1f", avgAssignment));
        updateStatLabel(avgMidtermLabel, String.format("%.1f", avgMidterm));
        updateStatLabel(avgFinalLabel, String.format("%.1f", avgFinal));
        updateStatLabel(passRateLabel, String.format("%.1f%%", passRate));
        updateStatLabel(failRateLabel, String.format("%.1f%%", failRate));
        
        // Update total students label
        JPanel totalStudentsPanel = (JPanel) ((JLabel) avgTotalLabel.getParent().getParent().getParent().getComponent(7)).getComponent(0);
        JLabel totalStudentsValue = (JLabel) totalStudentsPanel.getComponent(1);
        totalStudentsValue.setText(String.valueOf(rowCount));
    }

    private void updateStatLabel(JLabel label, String value) {
        JPanel card = (JPanel) label.getParent().getComponent(0);
        JLabel valueLabel = (JLabel) card.getComponent(1);
        valueLabel.setText(value);
    }

    private void searchStudent(String rollNo) {
        if (rollNo.isEmpty()) {
            return;
        }
        
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String currentRoll = tableModel.getValueAt(i, 2).toString();
            if (currentRoll.equalsIgnoreCase(rollNo)) {
                table.setRowSelectionInterval(i, i);
                table.scrollRectToVisible(table.getCellRect(i, 0, true));
                return;
            }
        }
        
        JOptionPane.showMessageDialog(this, "Student with Roll No " + rollNo + " not found in current list.");
    }

    private void saveChanges() {
        if (table.isEditing()) table.getCellEditor().stopCellEditing();
        if (subjectCombo.getSelectedItem() == null) return;

        int subjectId = selectedSubjectId();
        int semester = (Integer) semesterSpinner.getValue();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        UndoStack undoStack = SessionManager.getInstance().getUndoStack();

        try {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                Object markIdObj = tableModel.getValueAt(i, 0);
                int studentId = (Integer) tableModel.getValueAt(i, 1);
                double quiz = parseAndValidate(i, 4, 10, "Quiz");
                double assignment = parseAndValidate(i, 5, 15, "Assignment");
                double midterm = parseAndValidate(i, 6, 30, "Midterm");
                double finalExam = parseAndValidate(i, 7, 45, "Final Exam");
                double total = quiz + assignment + midterm + finalExam;
                String newValue = String.format("Q:%.2f,A:%.2f,M:%.2f,F:%.2f,T:%.2f", quiz, assignment, midterm, finalExam, total);

                if (markIdObj == null || markIdObj.toString().isBlank() || "0".equals(markIdObj.toString())) {
                    String ins = "INSERT INTO marks (student_id, subject_id, semester, quiz, assignment, midterm, final_exam) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(ins, Statement.RETURN_GENERATED_KEYS)) {
                        stmt.setInt(1, studentId);
                        stmt.setInt(2, subjectId);
                        stmt.setInt(3, semester);
                        stmt.setDouble(4, quiz);
                        stmt.setDouble(5, assignment);
                        stmt.setDouble(6, midterm);
                        stmt.setDouble(7, finalExam);
                        stmt.executeUpdate();
                        try (ResultSet keys = stmt.getGeneratedKeys()) {
                            if (keys.next()) {
                                int markId = keys.getInt(1);
                                tableModel.setValueAt(markId, i, 0);
                                ActionLogEntry log = createLog("INSERT", markId, "", newValue);
                                undoStack.push(log);
                                logAction(conn, log);
                            }
                        }
                    }
                } else {
                    int markId = Integer.parseInt(markIdObj.toString());
                    String upd = "UPDATE marks SET quiz=?, assignment=?, midterm=?, final_exam=? WHERE mark_id=?";
                    try (PreparedStatement stmt = conn.prepareStatement(upd)) {
                        stmt.setDouble(1, quiz);
                        stmt.setDouble(2, assignment);
                        stmt.setDouble(3, midterm);
                        stmt.setDouble(4, finalExam);
                        stmt.setInt(5, markId);
                        if (stmt.executeUpdate() > 0) {
                            logAction(conn, createLog("UPDATE", markId, "", newValue));
                        }
                    }
                }
                refreshCalculatedCells(i, total);
            }
            updateStatistics();
            JOptionPane.showMessageDialog(this, "Marks saved successfully.");
        } catch (IllegalArgumentException | SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        updateUndoButtonState();
    }

    private void deleteSelectedMark() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a marks row first.");
            return;
        }
        int modelRow = table.convertRowIndexToModel(row);
        Object markIdObj = tableModel.getValueAt(modelRow, 0);
        if (markIdObj == null || markIdObj.toString().isBlank()) {
            JOptionPane.showMessageDialog(this, "This row has no saved marks to delete.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Delete selected marks?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) return;

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        int markId = Integer.parseInt(markIdObj.toString());
        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM marks WHERE mark_id=?")) {
            stmt.setInt(1, markId);
            stmt.executeUpdate();
            logAction(conn, createLog("DELETE", markId, markIdObj.toString(), ""));
            tableModel.setValueAt(null, modelRow, 0);
            for (int col = 4; col <= 10; col++) {
                tableModel.setValueAt(col <= 7 ? 0.0 : "", modelRow, col);
            }
            updateStatistics();
            JOptionPane.showMessageDialog(this, "Marks deleted successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not delete marks: " + e.getMessage());
        }
    }

    private void performUndo() {
        UndoStack undoStack = SessionManager.getInstance().getUndoStack();
        if (undoStack.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nothing to undo.");
            return;
        }
        ActionLogEntry lastAction = undoStack.pop();
        if (!"INSERT".equals(lastAction.getActionType())) {
            JOptionPane.showMessageDialog(this, "Only the last added marks row can be undone safely.");
            updateUndoButtonState();
            return;
        }

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM marks WHERE mark_id=?")) {
            stmt.setInt(1, lastAction.getRecordId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Last added marks row was undone.");
            loadMarks();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Undo failed: " + e.getMessage());
        }
        updateUndoButtonState();
    }

    private void addMarksRow(Object markId, int studentId, String rollNo, String name, double quiz, double assignment, double midterm, double finalExam) {
        double total = quiz + assignment + midterm + finalExam;
        tableModel.addRow(new Object[]{
                markId, studentId, rollNo, name, quiz, assignment, midterm, finalExam,
                round(total), grade(total), gradePoint(total)
        });
    }

    private double parseAndValidate(int row, int col, double max, String label) {
        double value = parseDouble(tableModel.getValueAt(row, col));
        if (!Validator.isValidMark(value, max)) {
            throw new IllegalArgumentException(label + " must be between 0 and " + max + " on row " + (row + 1) + ".");
        }
        return value;
    }

    private void refreshCalculatedCells(int row, double total) {
        tableModel.setValueAt(round(total), row, 8);
        tableModel.setValueAt(grade(total), row, 9);
        tableModel.setValueAt(gradePoint(total), row, 10);
    }

    private int selectedSubjectId() {
        String selected = subjectCombo.getSelectedItem().toString();
        return Integer.parseInt(selected.split(" - ")[0]);
    }

    private ActionLogEntry createLog(String actionType, int recordId, String oldValue, String newValue) {
        User user = SessionManager.getInstance().getCurrentUser();
        int userId = user == null ? 0 : user.getUserId();
        return new ActionLogEntry(0, actionType, "marks", recordId, oldValue, newValue, userId, new Timestamp(System.currentTimeMillis()), false);
    }

    private void logAction(Connection conn, ActionLogEntry entry) throws SQLException {
        String q = "INSERT INTO action_log (action_type, table_name, record_id, old_value, new_value, performed_by) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setString(1, entry.getActionType());
            stmt.setString(2, entry.getTableName());
            stmt.setInt(3, entry.getRecordId());
            stmt.setString(4, entry.getOldValue());
            stmt.setString(5, entry.getNewValue());
            if (entry.getPerformedBy() == 0) {
                stmt.setNull(6, Types.INTEGER);
            } else {
                stmt.setInt(6, entry.getPerformedBy());
            }
            stmt.executeUpdate();
        }
    }

    private void updateUndoButtonState() {
        undoBtn.setEnabled(!SessionManager.getInstance().getUndoStack().isEmpty());
    }

    private double parseDouble(Object value) {
        if (value == null) return 0.0;
        try {
            return Double.parseDouble(value.toString());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private String grade(double total) {
        if (total >= 85) return "A";
        if (total >= 80) return "A-";
        if (total >= 75) return "B+";
        if (total >= 70) return "B";
        if (total >= 65) return "B-";
        if (total >= 60) return "C+";
        if (total >= 55) return "C";
        if (total >= 50) return "D";
        return "F";
    }

    private double gradePoint(double total) {
        if (total >= 85) return 4.0;
        if (total >= 80) return 3.7;
        if (total >= 75) return 3.3;
        if (total >= 70) return 3.0;
        if (total >= 65) return 2.7;
        if (total >= 60) return 2.3;
        if (total >= 55) return 2.0;
        if (total >= 50) return 1.7;
        return 0.0;
    }
}

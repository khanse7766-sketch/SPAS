package com.spas.logic;

import com.spas.datastructures.SemesterHistoryNode;
import com.spas.datastructures.StudentLinkedList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import java.util.Collections;
import java.util.List;

public class TrendAnalytics {

    public static JFreeChart createGpaTrendChart(StudentLinkedList history) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        if (history != null && !history.isEmpty()) {
            List<SemesterHistoryNode> list = history.traverse();
            // The list is most-recent first (inserted at head).
            // We should reverse it to plot chronologically (Semester 1 -> 8).
            Collections.reverse(list);
            
            for (SemesterHistoryNode node : list) {
                dataset.addValue(node.getGpa(), "GPA", "Sem " + node.getSemester());
            }
        }

        JFreeChart chart = ChartFactory.createLineChart(
                "GPA Trend",
                "Semester",
                "GPA",
                dataset
        );
        return chart;
    }
    
    public static String analyzeTrend(StudentLinkedList history) {
        if (history == null || history.getSize() < 2) return "Insufficient Data";
        
        List<SemesterHistoryNode> list = history.traverse(); // index 0 is newest, index 1 is older
        double currentGpa = list.get(0).getGpa();
        double prevGpa = list.get(1).getGpa();
        
        double diff = currentGpa - prevGpa;
        if (diff >= 0.2) return "Improving";
        if (diff <= -0.2) return "Declining";
        return "Stable";
    }
}

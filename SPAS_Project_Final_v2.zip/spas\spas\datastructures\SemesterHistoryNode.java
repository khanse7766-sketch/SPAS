package com.spas.datastructures;

/**
 * Node for the singly linked list representing a student's academic history.
 * Each node stores data for a specific subject in a specific semester.
 */
public class SemesterHistoryNode {
    private int semester;
    private int subjectId;
    private double gpa;
    private double cgpa;
    private int classRank;
    private double consistencyScore;
    private double amiScore;
    
    private SemesterHistoryNode next;

    public SemesterHistoryNode(int semester, double gpa, double cgpa, int classRank, double consistencyScore, double amiScore) {
        this.semester = semester;
        this.gpa = gpa;
        this.cgpa = cgpa;
        this.classRank = classRank;
        this.consistencyScore = consistencyScore;
        this.amiScore = amiScore;
        this.next = null;
    }

    // Getters and Setters
    public int getSemester() { return semester; }
    public double getGpa() { return gpa; }
    public double getCgpa() { return cgpa; }
    public int getClassRank() { return classRank; }
    public double getConsistencyScore() { return consistencyScore; }
    public double getAmiScore() { return amiScore; }
    public SemesterHistoryNode getNext() { return next; }
    public void setNext(SemesterHistoryNode next) { this.next = next; }
}

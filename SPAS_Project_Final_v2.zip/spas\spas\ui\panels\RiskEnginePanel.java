package com.spas.ui.panels;

import com.spas.db.DBManager;
import com.spas.logic.RiskEngine;
import com.spas.models.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RiskEnginePanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel chartContainer;

    public RiskEnginePanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Risk Engine (Prediction & Classification)");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        add(title, BorderLayout.NORTH);

        String[] cols = {"Roll No", "Name", "Failed Subjects", "GPA", "Attendance %", "Risk Level", "Recommendation"};
        tableModel = new DefaultTableModel(cols, 0);
        table = new JTable(tableModel);
        
        // Custom renderer for Risk Level colors
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column == 5) {
                    String val = value.toString();
                    if ("High".equals(val)) {
                        c.setForeground(Color.RED);
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if ("Medium".equals(val)) {
                        c.setForeground(new Color(255, 140, 0)); // Dark Orange
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else {
                        c.setForeground(new Color(0, 150, 0)); // Green
                        c.setFont(c.getFont().deriveFont(Font.PLAIN));
                    }
                } else {
                    c.setForeground(Color.BLACK);
                    c.setFont(c.getFont().deriveFont(Font.PLAIN));
                }
                return c;
            }
        });

        chartContainer = new JPanel(new BorderLayout());
        chartContainer.setPreferredSize(new Dimension(300, 0));
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(table), chartContainer);
        splitPane.setResizeWeight(0.6);
        add(splitPane, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton loadBtn = new JButton("Run Risk Analysis");
        loadBtn.addActionListener(e -> runAnalysis());
        bottom.add(loadBtn);
        add(bottom, BorderLayout.SOUTH);
    }

    private void runAnalysis() {
        tableModel.setRowCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        int high = 0, med = 0, low = 0;

        try {
            String q = "SELECT s.student_id, s.roll_no, u.full_name, " +
                       "(SELECT COUNT(*) FROM marks m WHERE m.student_id = s.student_id AND (m.quiz+m.assignment+m.midterm+m.final_exam) < 50) AS failed_count, " +
                       "COALESCE((SELECT AVG(gpa) FROM semester_summary ss WHERE ss.student_id = s.student_id), 0) AS gpa, " +
                       "COALESCE((SELECT AVG(status='PRESENT') * 100 FROM attendance a WHERE a.student_id = s.student_id), 100) AS attendance_pct " +
                       "FROM students s JOIN users u ON s.user_id = u.user_id";
            PreparedStatement stmt = conn.prepareStatement(q);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Student st = new Student(rs.getInt("student_id"), 0, rs.getString("roll_no"), "", 0, "", rs.getString("full_name"), "", "");
                int failedCount = rs.getInt("failed_count");
                double gpa = rs.getDouble("gpa");
                double attendance = rs.getDouble("attendance_pct");
                
                RiskEngine.RiskProfile profile = RiskEngine.assessStudentRisk(st, failedCount, attendance);
                String riskLevel = classifyRisk(gpa, attendance, failedCount, profile.riskLevel);
                
                if (riskLevel.equals("High")) high++;
                else if (riskLevel.equals("Medium")) med++;
                else low++;

                tableModel.addRow(new Object[]{
                    profile.student.getRollNo(),
                    profile.student.getFullName(),
                    profile.failedSubjectsCount,
                    round(gpa),
                    round(attendance) + "%",
                    riskLevel,
                    recommendation(gpa, attendance, failedCount)
                });
            }

            // Update Chart
            updateChart(high, med, low);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Risk analysis failed: " + e.getMessage());
        }
    }

    private String classifyRisk(double gpa, double attendance, int failedCount, String fallback) {
        if (gpa < 2.0 || attendance < 75 || failedCount > 1) return "High";
        if (gpa < 2.5 || attendance < 85 || failedCount == 1) return "Medium";
        if (attendance > 90 && gpa >= 3.0) return "Low";
        return fallback;
    }

    private String recommendation(double gpa, double attendance, int failedCount) {
        if (gpa < 2.0) return "Academic counseling and remedial plan required.";
        if (attendance < 75) return "Attendance warning and parent/mentor follow-up required.";
        if (failedCount > 0) return "Focus weak subjects and retake preparation.";
        return "Stable performance. Maintain current study plan.";
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private void updateChart(int high, int med, int low) {
        chartContainer.removeAll();
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("High Risk", high);
        dataset.setValue("Medium Risk", med);
        dataset.setValue("Low Risk", low);

        JFreeChart chart = ChartFactory.createPieChart(
                "Risk Distribution",
                dataset,
                true, true, false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartContainer.add(chartPanel, BorderLayout.CENTER);
        chartContainer.revalidate();
        chartContainer.repaint();
    }
}

package com.spas.ui.theme;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.spas.db.DBManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Window;

public class ThemeManager {

    private static boolean isDarkMode = false;

    public static void initializeTheme() {
        // Try to load from DB
        Connection conn = DBManager.getInstance().getConnection();
        if (conn != null) {
            try {
                String q = "SELECT pref_value FROM system_preferences WHERE pref_key = 'theme'";
                PreparedStatement stmt = conn.prepareStatement(q);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    isDarkMode = "dark".equals(rs.getString("pref_value"));
                }
            } catch (SQLException e) {
                // Ignore
            }
        }
        applyTheme();
    }

    public static void toggleTheme() {
        isDarkMode = !isDarkMode;
        applyTheme();
        saveThemePreference();
        
        // Update all existing windows
        for (Window window : Window.getWindows()) {
            SwingUtilities.updateComponentTreeUI(window);
        }
    }

    private static void applyTheme() {
        try {
            if (isDarkMode) {
                UIManager.setLookAndFeel(new FlatDarkLaf());
            } else {
                UIManager.setLookAndFeel(new FlatLightLaf());
            }
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF");
        }
    }

    private static void saveThemePreference() {
        Connection conn = DBManager.getInstance().getConnection();
        if (conn != null) {
            try {
                String q = "INSERT INTO system_preferences (pref_key, pref_value) VALUES ('theme', ?) ON DUPLICATE KEY UPDATE pref_value = ?";
                PreparedStatement stmt = conn.prepareStatement(q);
                String val = isDarkMode ? "dark" : "light";
                stmt.setString(1, val);
                stmt.setString(2, val);
                stmt.executeUpdate();
            } catch (SQLException e) {
                // Ignore
            }
        }
    }

    public static boolean isDarkMode() {
        return isDarkMode;
    }
}

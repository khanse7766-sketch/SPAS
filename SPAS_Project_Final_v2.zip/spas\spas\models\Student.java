package com.spas.models;

public class Student {
    private int studentId;
    private int userId;
    private String rollNo;
    private String batch;
    private int currentSemester;
    private String photoPath;

    // Derived from User
    private String fullName;
    private String email;
    private String phone;

    public Student(int studentId, int userId, String rollNo, String batch, int currentSemester, String photoPath, String fullName, String email, String phone) {
        this.studentId = studentId;
        this.userId = userId;
        this.rollNo = rollNo;
        this.batch = batch;
        this.currentSemester = currentSemester;
        this.photoPath = photoPath;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
    }

    public int getStudentId() { return studentId; }
    public int getUserId() { return userId; }
    public String getRollNo() { return rollNo; }
    public String getBatch() { return batch; }
    public int getCurrentSemester() { return currentSemester; }
    public String getPhotoPath() { return photoPath; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
}

package com.spas.ui.panels;

import com.spas.db.DBManager;
import com.spas.logic.RankingEngine;
import com.spas.models.Student;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RankingPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JSpinner semesterSpinner;
    private JLabel totalStudentsLabel;
    private JLabel avgGpaLabel;
    private JLabel avgMarksLabel;
    private JLabel highestGpaLabel;
    private JLabel lowestGpaLabel;

    public RankingPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Ranking Engine");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        
        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Updated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);
        
        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createControlPanel(), BorderLayout.NORTH);
        topPanel.add(createStatisticsCards(), BorderLayout.CENTER);
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, createTablePanel());
        splitPane.setResizeWeight(0.3);
        
        content.add(splitPane, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createTitledBorder("Ranking Controls"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        
        semesterSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 8, 1));
        
        JButton calcBtn = createStyledButton("Calculate & Save Rankings", new Color(47, 93, 255));
        JButton refreshBtn = createStyledButton("Refresh", new Color(13, 110, 253));
        
        calcBtn.addActionListener(e -> calculateRankings());
        refreshBtn.addActionListener(e -> loadRankings());
        
        controls.add(new JLabel("Semester:"));
        controls.add(semesterSpinner);
        controls.add(Box.createHorizontalStrut(10));
        controls.add(calcBtn);
        controls.add(refreshBtn);
        
        panel.add(controls, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createStatisticsCards() {
        JPanel cardsPanel = new JPanel(new GridLayout(1, 5, 10, 10));
        
        totalStudentsLabel = createStatCard("Total Students", "0", new Color(47, 93, 255));
        avgGpaLabel = createStatCard("Average GPA", "0.0", new Color(25, 145, 85));
        avgMarksLabel = createStatCard("Average Marks", "0.0", new Color(255, 165, 0));
        highestGpaLabel = createStatCard("Highest GPA", "0.0", new Color(25, 145, 85));
        lowestGpaLabel = createStatCard("Lowest GPA", "0.0", new Color(220, 53, 69));
        
        cardsPanel.add(totalStudentsLabel);
        cardsPanel.add(avgGpaLabel);
        cardsPanel.add(avgMarksLabel);
        cardsPanel.add(highestGpaLabel);
        cardsPanel.add(lowestGpaLabel);
        
        return cardsPanel;
    }

    private JLabel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        JLabel wrapper = new JLabel();
        wrapper.setLayout(new BorderLayout());
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Student Rankings"));
        
        String[] cols = {"Rank", "Student ID", "Roll No", "Name", "Total Marks", "GPA", "Explainable AI Result"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setAutoCreateRowSorter(true);
        
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));
        
        JLabel statusLabel = new JLabel("Ready | Select semester and calculate rankings");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        
        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Ranking Engine Module"), BorderLayout.EAST);
        
        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(180, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void calculateRankings() {
        tableModel.setRowCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        int semester = (Integer) semesterSpinner.getValue();

        String q = "SELECT s.student_id, s.roll_no, u.full_name, " +
                "COALESCE(SUM(m.quiz + m.assignment + m.midterm + m.final_exam), 0) AS total_marks, " +
                "COALESCE(AVG(CASE " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 85 THEN 4.0 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 80 THEN 3.7 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 75 THEN 3.3 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 70 THEN 3.0 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 65 THEN 2.7 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 60 THEN 2.3 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 55 THEN 2.0 " +
                "WHEN (m.quiz + m.assignment + m.midterm + m.final_exam) >= 50 THEN 1.7 ELSE 0.0 END), 0) AS gpa " +
                "FROM students s JOIN users u ON s.user_id = u.user_id " +
                "LEFT JOIN marks m ON s.student_id = m.student_id AND m.semester = ? " +
                "GROUP BY s.student_id, s.roll_no, u.full_name";

        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setInt(1, semester);
            List<RankingEngine.RankedStudent> ranked = new ArrayList<>();
            List<Double> totals = new ArrayList<>();

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Student student = new Student(
                            rs.getInt("student_id"), 0, rs.getString("roll_no"), "", semester, "",
                            rs.getString("full_name"), "", ""
                    );
                    double gpa = rs.getDouble("gpa");
                    ranked.add(new RankingEngine.RankedStudent(student, gpa));
                    totals.add(rs.getDouble("total_marks"));
                }
            }

            RankingEngine.RankedStudent[] arr = ranked.toArray(new RankingEngine.RankedStudent[0]);
            double[] totalArr = new double[totals.size()];
            for (int i = 0; i < totals.size(); i++) totalArr[i] = totals.get(i);
            sortTogether(arr, totalArr, 0, arr.length - 1);

            saveSemesterSummary(conn, semester, arr);
            for (int i = 0; i < arr.length; i++) {
                String explanation = String.format("Rank #%d because GPA %.2f and total marks %.2f were sorted with Quick Sort.",
                        i + 1, arr[i].score, totalArr[i]);
                tableModel.addRow(new Object[]{
                        i + 1,
                        arr[i].student.getStudentId(),
                        arr[i].student.getRollNo(),
                        arr[i].student.getFullName(),
                        round(totalArr[i]),
                        round(arr[i].score),
                        explanation
                });
            }
            JOptionPane.showMessageDialog(this, "Rankings saved to semester_summary.");
            updateStatistics();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not calculate rankings: " + e.getMessage());
        }
    }

    private void loadRankings() {
        tableModel.setRowCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        int semester = (Integer) semesterSpinner.getValue();

        String q = "SELECT ss.class_rank, s.student_id, s.roll_no, u.full_name, " +
                "COALESCE(SUM(m.quiz + m.assignment + m.midterm + m.final_exam), 0) AS total_marks, " +
                "ss.gpa FROM semester_summary ss " +
                "JOIN students s ON ss.student_id = s.student_id " +
                "JOIN users u ON s.user_id = u.user_id " +
                "LEFT JOIN marks m ON s.student_id = m.student_id AND m.semester = ? " +
                "WHERE ss.semester = ? " +
                "GROUP BY s.student_id, s.roll_no, u.full_name, ss.class_rank, ss.gpa " +
                "ORDER BY ss.class_rank";

        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setInt(1, semester);
            stmt.setInt(2, semester);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String explanation = String.format("Rank #%d based on GPA %.2f and total marks %.2f.",
                        rs.getInt("class_rank"), rs.getDouble("gpa"), rs.getDouble("total_marks"));
                tableModel.addRow(new Object[]{
                        rs.getInt("class_rank"),
                        rs.getInt("student_id"),
                        rs.getString("roll_no"),
                        rs.getString("full_name"),
                        round(rs.getDouble("total_marks")),
                        round(rs.getDouble("gpa")),
                        explanation
                });
            }
            updateStatistics();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load rankings: " + e.getMessage());
        }
    }

    private void updateStatistics() {
        int rowCount = tableModel.getRowCount();
        updateStatLabel(totalStudentsLabel, String.valueOf(rowCount));
        
        if (rowCount > 0) {
            double totalGpa = 0;
            double totalMarks = 0;
            double highestGpa = 0;
            double lowestGpa = 4.0;
            
            for (int i = 0; i < rowCount; i++) {
                double gpa = parseDouble(tableModel.getValueAt(i, 5));
                double marks = parseDouble(tableModel.getValueAt(i, 4));
                totalGpa += gpa;
                totalMarks += marks;
                if (gpa > highestGpa) highestGpa = gpa;
                if (gpa < lowestGpa) lowestGpa = gpa;
            }
            
            updateStatLabel(avgGpaLabel, String.format("%.2f", totalGpa / rowCount));
            updateStatLabel(avgMarksLabel, String.format("%.1f", totalMarks / rowCount));
            updateStatLabel(highestGpaLabel, String.format("%.2f", highestGpa));
            updateStatLabel(lowestGpaLabel, String.format("%.2f", lowestGpa));
        }
    }

    private void updateStatLabel(JLabel label, String value) {
        JPanel card = (JPanel) label.getParent().getComponent(0);
        JLabel valueLabel = (JLabel) card.getComponent(1);
        valueLabel.setText(value);
    }

    private double parseDouble(Object value) {
        if (value == null) return 0.0;
        try {
            return Double.parseDouble(value.toString());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private void saveSemesterSummary(Connection conn, int semester, RankingEngine.RankedStudent[] arr) throws SQLException {
        try (PreparedStatement delete = conn.prepareStatement("DELETE FROM semester_summary WHERE semester=?")) {
            delete.setInt(1, semester);
            delete.executeUpdate();
        }
        String q = "INSERT INTO semester_summary (student_id, semester, gpa, cgpa, class_rank, consistency_score, ami_score) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement insert = conn.prepareStatement(q)) {
            for (int i = 0; i < arr.length; i++) {
                double gpa = round(arr[i].score);
                insert.setInt(1, arr[i].student.getStudentId());
                insert.setInt(2, semester);
                insert.setDouble(3, gpa);
                insert.setDouble(4, gpa);
                insert.setInt(5, i + 1);
                insert.setDouble(6, Math.min(100, gpa * 25));
                insert.setDouble(7, Math.min(100, gpa * 25));
                insert.addBatch();
            }
            insert.executeBatch();
        }
    }

    private void sortTogether(RankingEngine.RankedStudent[] arr, double[] totals, int low, int high) {
        if (low >= high) return;
        int pivot = partition(arr, totals, low, high);
        sortTogether(arr, totals, low, pivot - 1);
        sortTogether(arr, totals, pivot + 1, high);
    }

    private int partition(RankingEngine.RankedStudent[] arr, double[] totals, int low, int high) {
        double pivot = arr[high].score;
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j].score > pivot || (arr[j].score == pivot && totals[j] > totals[high])) {
                i++;
                swap(arr, totals, i, j);
            }
        }
        swap(arr, totals, i + 1, high);
        return i + 1;
    }

    private void swap(RankingEngine.RankedStudent[] arr, double[] totals, int i, int j) {
        RankingEngine.RankedStudent st = arr[i];
        arr[i] = arr[j];
        arr[j] = st;
        double total = totals[i];
        totals[i] = totals[j];
        totals[j] = total;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}

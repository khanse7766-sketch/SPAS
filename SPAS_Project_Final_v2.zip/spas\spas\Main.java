package com.spas;

import com.spas.auth.LoginFrame;
import com.spas.db.DBManager;
import com.spas.db.SeedData;
import javax.swing.UIManager;

import javax.swing.SwingUtilities;
import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        // Initialize Look & Feel (system default)
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            System.err.println("Failed to initialize FlatLaf");
        }

        // Initialize Database and Seed Data
        Connection conn = DBManager.getInstance().getConnection();
        if (conn != null) {
            SeedData.initializeSeedData(conn);
        } else {
            System.err.println("WARNING: Could not connect to the database. Ensure XAMPP MySQL is running.");
        }

        // Launch Login UI
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}

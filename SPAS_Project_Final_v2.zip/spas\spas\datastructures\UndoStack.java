package com.spas.datastructures;

import com.spas.models.ActionLogEntry;

/**
 * Custom Stack implementation to satisfy CS-201 project requirements.
 * Used for maintaining undo history.
 */
public class UndoStack {
    private ActionLogEntry[] stack;
    private int top;
    private int capacity;

    public UndoStack(int capacity) {
        this.capacity = capacity;
        this.stack = new ActionLogEntry[capacity];
        this.top = -1;
    }

    public boolean push(ActionLogEntry entry) {
        if (isFull()) {
            // Shift elements left to make room (forget oldest action)
            for (int i = 0; i < capacity - 1; i++) {
                stack[i] = stack[i + 1];
            }
            top--;
        }
        stack[++top] = entry;
        return true;
    }

    public ActionLogEntry pop() {
        if (isEmpty()) {
            return null;
        }
        return stack[top--];
    }

    public ActionLogEntry peek() {
        if (isEmpty()) {
            return null;
        }
        return stack[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == capacity - 1;
    }
    
    public int getSize() {
        return top + 1;
    }
    
    public void clear() {
        top = -1;
    }
}

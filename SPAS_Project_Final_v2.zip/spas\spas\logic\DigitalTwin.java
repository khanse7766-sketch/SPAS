package com.spas.logic;

import com.spas.datastructures.SemesterHistoryNode;
import com.spas.datastructures.StudentLinkedList;
import java.util.List;

public class DigitalTwin {
    /**
     * Predicts the next semester's CGPA based on the last 3 semesters using weighted linear projection.
     */
    public static double predictNextCgpa(StudentLinkedList history) {
        if (history == null || history.getSize() < 1) return 0.0;
        
        List<SemesterHistoryNode> list = history.traverse(); // index 0 is newest
        
        if (list.size() == 1) {
            return list.get(0).getCgpa();
        } else if (list.size() == 2) {
            double w1 = 0.7; // most recent
            double w2 = 0.3; // older
            return (list.get(0).getCgpa() * w1) + (list.get(1).getCgpa() * w2);
        } else {
            double w1 = 0.6; // most recent
            double w2 = 0.3;
            double w3 = 0.1; // oldest of the 3
            return (list.get(0).getCgpa() * w1) + (list.get(1).getCgpa() * w2) + (list.get(2).getCgpa() * w3);
        }
    }
}

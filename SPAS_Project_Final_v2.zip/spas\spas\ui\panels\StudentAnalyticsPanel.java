package com.spas.ui.panels;

import com.formdev.flatlaf.FlatClientProperties;
import com.spas.db.DBManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.RingPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentAnalyticsPanel extends JPanel {

    public StudentAnalyticsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 246, 250));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        // TOP HEADER
        add(createHeader(), BorderLayout.NORTH);

        // MAIN CONTENT
        JPanel mainContent = new JPanel();
        mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.Y_AXIS));
        mainContent.setOpaque(false);

        mainContent.add(createKpiCards());
        mainContent.add(Box.createRigidArea(new Dimension(0, 15)));
        mainContent.add(createMiddleCharts());
        mainContent.add(Box.createRigidArea(new Dimension(0, 15)));
        mainContent.add(createBottomRow());

        add(new JScrollPane(mainContent), BorderLayout.CENTER);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("🎓 STUDENT PERFORMANCE DASHBOARD");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 80));

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        filters.setOpaque(false);
        filters.add(createDropdown("Academic Year", new String[]{"2023 - 2024", "2024 - 2025"}));
        filters.add(createDropdown("Class", new String[]{"All", "10A", "10B", "10C"}));
        filters.add(createDropdown("Subject", new String[]{"All", "Mathematics", "Science"}));

        header.add(title, BorderLayout.WEST);
        header.add(filters, BorderLayout.EAST);
        return header;
    }

    private JPanel createDropdown(String label, String[] options) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setOpaque(false);
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JComboBox<String> combo = new JComboBox<>(options);
        combo.putClientProperty(FlatClientProperties.STYLE, "arc: 5");
        panel.add(l, BorderLayout.WEST);
        panel.add(combo, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createKpiCards() {
        JPanel panel = new JPanel(new GridLayout(1, 5, 15, 0));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(0, 100));
        panel.setMaximumSize(new Dimension(9999, 100));

        panel.add(createCard("Total Students", "1,250", "▲ 8.5% vs Last Year", new Color(230, 240, 255)));
        panel.add(createCard("Average Score", "A+ 78.4%", "▲ 5.2% vs Last Year", new Color(230, 250, 230)));
        panel.add(createCard("Pass Percentage", "88.6%", "▲ 7.2% vs Last Year", new Color(255, 250, 230)));
        panel.add(createCard("Top Score", "98%", "Highest Score", new Color(245, 230, 255)));
        panel.add(createCard("Students at Risk", "64", "▼ 12.3% vs Last Year", new Color(255, 235, 235)));

        return panel;
    }

    private JPanel createCard(String title, String value, String subtitle, Color bgColor) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.putClientProperty(FlatClientProperties.STYLE, "arc: 15");
        card.setBorder(new EmptyBorder(10, 15, 10, 15));

        // Sub-panel for colored background effect if needed
        JPanel inner = new JPanel(new BorderLayout());
        inner.setBackground(bgColor);
        inner.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
        inner.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.setForeground(Color.DARK_GRAY);

        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI", Font.BOLD, 26));
        v.setForeground(Color.BLACK);

        JLabel s = new JLabel(subtitle);
        s.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        if (subtitle.contains("▲")) s.setForeground(new Color(40, 160, 60));
        else if (subtitle.contains("▼")) s.setForeground(new Color(200, 40, 40));
        else s.setForeground(Color.GRAY);

        inner.add(t, BorderLayout.NORTH);
        inner.add(v, BorderLayout.CENTER);
        inner.add(s, BorderLayout.SOUTH);
        
        card.add(inner);
        return card;
    }

    private JPanel createMiddleCharts() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 15, 0));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(0, 300));
        panel.setMaximumSize(new Dimension(9999, 300));

        panel.add(createChartWrapper("Average Score Over Time", new ChartPanel(createLineChart())));
        panel.add(createChartWrapper("Performance by Grade", new ChartPanel(createGradeRingChart())));
        panel.add(createChartWrapper("Pass vs Fail", new ChartPanel(createPassFailRingChart())));

        return panel;
    }

    private JPanel createBottomRow() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 15, 0));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(0, 300));
        panel.setMaximumSize(new Dimension(9999, 300));

        panel.add(createChartWrapper("Average Score by Subject", new ChartPanel(createBarChart())));
        panel.add(createChartWrapper("Top 5 Students", createTopStudentsTable()));
        panel.add(createChartWrapper("Students at Risk", createRiskStudentsTable()));

        return panel;
    }

    private JPanel createChartWrapper(String title, JComponent chartOrTable) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 10));
        wrapper.setBackground(Color.WHITE);
        wrapper.putClientProperty(FlatClientProperties.STYLE, "arc: 15");
        wrapper.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 14));
        wrapper.add(t, BorderLayout.NORTH);
        wrapper.add(chartOrTable, BorderLayout.CENTER);

        return wrapper;
    }

    private JFreeChart createLineChart() {
        DefaultCategoryDataset ds = new DefaultCategoryDataset();
        ds.addValue(62, "Score", "Oct 2023");
        ds.addValue(65, "Score", "Nov 2023");
        ds.addValue(70, "Score", "Dec 2023");
        ds.addValue(74, "Score", "Jan 2024");
        ds.addValue(78, "Score", "Feb 2024");
        ds.addValue(82, "Score", "Mar 2024");

        JFreeChart chart = ChartFactory.createLineChart("", "", "", ds, PlotOrientation.VERTICAL, false, true, false);
        styleChart(chart);
        
        CategoryPlot plot = chart.getCategoryPlot();
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setSeriesPaint(0, new Color(40, 100, 180));
        renderer.setSeriesStroke(0, new BasicStroke(3.0f));
        plot.setRenderer(renderer);

        return chart;
    }

    private JFreeChart createGradeRingChart() {
        DefaultPieDataset ds = new DefaultPieDataset();
        ds.setValue("A (90-100)", 32);
        ds.setValue("B (80-89)", 28);
        ds.setValue("C (70-79)", 20);
        ds.setValue("D (60-69)", 12);
        ds.setValue("F (<60)", 8);

        JFreeChart chart = ChartFactory.createRingChart("", ds, true, true, false);
        styleChart(chart);
        RingPlot plot = (RingPlot) chart.getPlot();
        plot.setSectionDepth(0.3);
        plot.setLabelGenerator(null); // Hide labels on pie
        plot.setSectionPaint("A (90-100)", new Color(40, 160, 60));
        plot.setSectionPaint("B (80-89)", new Color(120, 200, 80));
        plot.setSectionPaint("C (70-79)", new Color(250, 180, 40));
        plot.setSectionPaint("D (60-69)", new Color(240, 120, 40));
        plot.setSectionPaint("F (<60)", new Color(200, 40, 40));
        return chart;
    }

    private JFreeChart createPassFailRingChart() {
        DefaultPieDataset ds = new DefaultPieDataset();
        ds.setValue("Passed", 88.6);
        ds.setValue("Failed", 11.4);

        JFreeChart chart = ChartFactory.createRingChart("", ds, true, true, false);
        styleChart(chart);
        RingPlot plot = (RingPlot) chart.getPlot();
        plot.setSectionDepth(0.3);
        plot.setLabelGenerator(null);
        plot.setSectionPaint("Passed", new Color(40, 160, 60));
        plot.setSectionPaint("Failed", new Color(200, 40, 40));
        return chart;
    }

    private JFreeChart createBarChart() {
        DefaultCategoryDataset ds = new DefaultCategoryDataset();
        ds.addValue(82, "Score", "Mathematics");
        ds.addValue(79, "Score", "Science");
        ds.addValue(75, "Score", "English");
        ds.addValue(72, "Score", "Social Science");
        ds.addValue(85, "Score", "Computer");

        JFreeChart chart = ChartFactory.createBarChart("", "", "", ds, PlotOrientation.HORIZONTAL, false, true, false);
        styleChart(chart);
        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(40, 100, 180));
        return chart;
    }

    private void styleChart(JFreeChart chart) {
        chart.setBackgroundPaint(Color.WHITE);
        if (chart.getPlot() instanceof CategoryPlot) {
            CategoryPlot plot = chart.getCategoryPlot();
            plot.setBackgroundPaint(Color.WHITE);
            plot.setOutlineVisible(false);
            plot.getDomainAxis().setAxisLineVisible(false);
            plot.getRangeAxis().setAxisLineVisible(false);
            plot.setDomainGridlinesVisible(false);
            plot.setRangeGridlinePaint(new Color(230, 230, 230));
        } else if (chart.getPlot() instanceof PiePlot) {
            PiePlot plot = (PiePlot) chart.getPlot();
            plot.setBackgroundPaint(Color.WHITE);
            plot.setOutlineVisible(false);
            plot.setShadowPaint(null);
        }
    }

    private JComponent createTopStudentsTable() {
        String[] cols = {"Student Name", "Class", "Average Score"};
        Object[][] data = {
                {"Aarav Sharma", "10A", "98%"},
                {"Diya Patel", "10B", "94%"},
                {"Rohan Verma", "10A", "92%"},
                {"Sneha Gupta", "10C", "91%"},
                {"Arjun Mehta", "10B", "90%"}
        };
        return createStyledTable(cols, data);
    }

    private JComponent createRiskStudentsTable() {
        String[] cols = {"Student Name", "Class", "Average Score"};
        Object[][] data = {
                {"Karan Singh", "10C", "45%"},
                {"Pooja Yadav", "10A", "52%"},
                {"Imran Khan", "10B", "55%"},
                {"Neha Kumari", "10C", "57%"},
                {"Vivek Tiwari", "10A", "58%"}
        };
        return createStyledTable(cols, data);
    }

    private JComponent createStyledTable(String[] cols, Object[][] data) {
        JTable table = new JTable(new DefaultTableModel(data, cols));
        table.setFillsViewportHeight(true);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setRowHeight(30);
        table.getTableHeader().setBackground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Color.WHITE);
        return scroll;
    }
}

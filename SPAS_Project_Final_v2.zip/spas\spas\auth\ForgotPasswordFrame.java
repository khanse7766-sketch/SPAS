package com.spas.auth;

import com.formdev.flatlaf.FlatClientProperties;
import com.spas.db.DBManager;
import com.spas.ui.theme.ThemeManager;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ForgotPasswordFrame extends JFrame {
    private JTextField emailField, phoneField;
    private JPasswordField newPasswordField, confirmPasswordField;
    private JButton updateBtn, themeToggleBtn;
    private JLabel errorLabel;

    public ForgotPasswordFrame() {
        setTitle("SPAS - Forgot Password");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        ThemeManager.initializeTheme();
        initUI();
    }

    private void initUI() {
        JPanel container = new JPanel(new BorderLayout());
        container.putClientProperty(FlatClientProperties.STYLE, "background: $Panel.background");

        // Top bar for theme toggle
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topPanel.setOpaque(false);
        themeToggleBtn = new JButton(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
        themeToggleBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 10; borderWidth: 0; focusWidth: 0;");
        themeToggleBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        themeToggleBtn.addActionListener(e -> {
            ThemeManager.toggleTheme();
            themeToggleBtn.setText(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
            SwingUtilities.updateComponentTreeUI(this);
        });
        topPanel.add(themeToggleBtn);
        container.add(topPanel, BorderLayout.NORTH);

        // Main content
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setOpaque(false);
        mainPanel.setBorder(new EmptyBorder(10, 40, 40, 40));

        // Title
        JLabel titleLabel = new JLabel("Reset Password");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Subtitle
        JPanel subtitlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        subtitlePanel.setOpaque(false);
        JLabel subtitleLabel = new JLabel("Remembered your password?");
        subtitleLabel.setForeground(Color.GRAY);
        JLabel signInLabel = new JLabel("Sign In");
        signInLabel.setForeground(new Color(47, 93, 255));
        signInLabel.setFont(signInLabel.getFont().deriveFont(Font.BOLD));
        signInLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signInLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });
        subtitlePanel.add(subtitleLabel);
        subtitlePanel.add(signInLabel);
        mainPanel.add(subtitlePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Email Field
        emailField = new JTextField();
        emailField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Registered Email Address");
        emailField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        emailField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(emailField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Phone Field
        phoneField = new JTextField();
        phoneField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Registered Phone Number (For Verification)");
        phoneField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        phoneField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(phoneField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // New Password Field
        newPasswordField = new JPasswordField();
        newPasswordField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "New Password");
        newPasswordField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10; showRevealButton: true;");
        newPasswordField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(newPasswordField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Confirm Password Field
        confirmPasswordField = new JPasswordField();
        confirmPasswordField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Confirm New Password");
        confirmPasswordField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10; showRevealButton: true;");
        confirmPasswordField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(confirmPasswordField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Error/Success Label
        errorLabel = new JLabel(" ");
        errorLabel.setForeground(new Color(220, 53, 69)); // Red
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        errorLabel.setVisible(false);
        mainPanel.add(errorLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Update Button
        updateBtn = new JButton("Reset Password");
        updateBtn.setBackground(new Color(24, 119, 242));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        updateBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 10; borderWidth: 0; focusWidth: 0;");
        updateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        updateBtn.setMaximumSize(new Dimension(500, 45));
        updateBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(updateBtn);

        updateBtn.addActionListener(e -> attemptReset());

        container.add(mainPanel, BorderLayout.CENTER);
        add(container);
    }

    private void attemptReset() {
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String newPass = new String(newPasswordField.getPassword());
        String confirmPass = new String(confirmPasswordField.getPassword());

        if (email.isEmpty() || phone.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
            showMsg("All fields are required.", false);
            return;
        }

        if (!newPass.equals(confirmPass)) {
            showMsg("Passwords do not match.", false);
            return;
        }

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            showMsg("Database connection error.", false);
            return;
        }

        try {
            // Verify if user exists with matching email and phone
            String verifyQ = "SELECT user_id FROM users WHERE email = ? AND phone = ?";
            PreparedStatement verifyStmt = conn.prepareStatement(verifyQ);
            verifyStmt.setString(1, email);
            verifyStmt.setString(2, phone);
            ResultSet rs = verifyStmt.executeQuery();
            
            if (rs.next()) {
                // User verified, update password and unlock account if locked
                int userId = rs.getInt("user_id");
                String updateQ = "UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE user_id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateQ);
                updateStmt.setString(1, BCrypt.hashpw(newPass, BCrypt.gensalt()));
                updateStmt.setInt(2, userId);
                updateStmt.executeUpdate();

                showMsg("Password updated successfully!", true);
                updateBtn.setEnabled(false);
                
                Timer timer = new Timer(1500, e -> {
                    new LoginFrame().setVisible(true);
                    dispose();
                });
                timer.setRepeats(false);
                timer.start();
            } else {
                showMsg("Invalid email or phone number combination.", false);
            }
        } catch (Exception e) {
            showMsg("An error occurred. Try again.", false);
            e.printStackTrace();
        }
    }

    private void showMsg(String msg, boolean isSuccess) {
        errorLabel.setForeground(isSuccess ? new Color(40, 167, 69) : new Color(220, 53, 69));
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }
}

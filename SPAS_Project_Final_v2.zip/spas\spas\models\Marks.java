package com.spas.models;

public class Marks {
    private int markId;
    private int studentId;
    private int subjectId;
    private int semester;
    private double quiz;
    private double assignment;
    private double midterm;
    private double finalExam;

    public Marks(int markId, int studentId, int subjectId, int semester, double quiz, double assignment, double midterm, double finalExam) {
        this.markId = markId;
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.semester = semester;
        this.quiz = quiz;
        this.assignment = assignment;
        this.midterm = midterm;
        this.finalExam = finalExam;
    }

    public int getMarkId() { return markId; }
    public int getStudentId() { return studentId; }
    public int getSubjectId() { return subjectId; }
    public int getSemester() { return semester; }
    public double getQuiz() { return quiz; }
    public double getAssignment() { return assignment; }
    public double getMidterm() { return midterm; }
    public double getFinalExam() { return finalExam; }
    
    public double getTotal() {
        return quiz + assignment + midterm + finalExam;
    }
}

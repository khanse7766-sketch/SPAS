package com.spas.ui.panels;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

public class TeacherHomePanel extends JPanel {

    public TeacherHomePanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(250, 246, 235)); // Warm off-white background from screenshot
        
        // --- TOP BANNER ---
        JPanel bannerPanel = new JPanel();
        bannerPanel.setLayout(new BoxLayout(bannerPanel, BoxLayout.Y_AXIS));
        bannerPanel.setBackground(new Color(255, 235, 85)); // Bright yellow
        bannerPanel.setBorder(new EmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("TO-DO LISTS");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 32)); // Playful font
        titleLabel.setForeground(new Color(40, 40, 40));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Organize your daily routines.");
        subtitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        subtitleLabel.setForeground(new Color(60, 60, 60));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        bannerPanel.add(titleLabel);
        bannerPanel.add(subtitleLabel);
        
        // Add banner to a wrapper to give it some margin
        JPanel bannerWrapper = new JPanel(new BorderLayout());
        bannerWrapper.setOpaque(false);
        bannerWrapper.setBorder(new EmptyBorder(20, 20, 10, 20));
        
        // Round the banner
        bannerPanel.putClientProperty(FlatClientProperties.STYLE, "arc: 20");
        bannerWrapper.add(bannerPanel, BorderLayout.CENTER);
        
        add(bannerWrapper, BorderLayout.NORTH);
        
        // --- GRID OF CARDS ---
        JPanel gridPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        gridPanel.setOpaque(false);
        gridPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        
        // Create the 6 day cards
        gridPanel.add(createDayCard("📖 MONDAY", new Color(245, 110, 145), new String[]{"Review for the week", "Grade assignments", "Item 3", "Item 4", "Item 5"}));
        gridPanel.add(createDayCard("✏️ TUESDAY", new Color(245, 165, 55), new String[]{"Outline next week's plans", "Update attendance", "Item 3", "Item 4", "Item 5"}));
        gridPanel.add(createDayCard("📒 WEDNESDAY", new Color(255, 220, 70), new String[]{"Finish lesson plans", "Staff meeting", "Item 3", "Item 4", "Item 5"}));
        gridPanel.add(createDayCard("📄 THURSDAY", new Color(175, 225, 95), new String[]{"Make copies", "Email parents", "Item 3", "Item 4", "Item 5"}));
        gridPanel.add(createDayCard("🦉 FRIDAY", new Color(110, 215, 210), new String[]{"Reset for next week", "Submit grades", "Item 3", "Item 4", "Item 5"}));
        gridPanel.add(createDayCard("➔ NEXT WEEK", new Color(100, 190, 245), new String[]{"Plan upcoming events", "Item 2", "Item 3", "Item 4", "Item 5"}));
        
        add(gridPanel, BorderLayout.CENTER);
    }
    
    private JPanel createDayCard(String headerText, Color headerColor, String[] tasks) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.putClientProperty(FlatClientProperties.STYLE, "arc: 25");
        
        // Apply a subtle border that matches the header color for a cohesive look
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 220, 220), 2, true),
                new EmptyBorder(0, 0, 10, 0)
        ));

        // Header Panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(headerColor);
        // We use FlatLaf arc on the header panel to round top corners.
        headerPanel.putClientProperty(FlatClientProperties.STYLE, "arc: 20");
        headerPanel.setBorder(new EmptyBorder(8, 0, 8, 0));
        
        JLabel headerLabel = new JLabel(headerText);
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        headerLabel.setForeground(Color.BLACK);
        headerPanel.add(headerLabel);
        
        // Wrap header to prevent it from stretching too tall, and add bottom margin
        JPanel headerWrapper = new JPanel(new BorderLayout());
        headerWrapper.setOpaque(false);
        headerWrapper.add(headerPanel, BorderLayout.CENTER);
        headerWrapper.setBorder(new EmptyBorder(5, 5, 10, 5));
        
        card.add(headerWrapper, BorderLayout.NORTH);
        
        // Body Panel (Checkboxes)
        JPanel bodyPanel = new JPanel();
        bodyPanel.setLayout(new BoxLayout(bodyPanel, BoxLayout.Y_AXIS));
        bodyPanel.setOpaque(false);
        bodyPanel.setBorder(new EmptyBorder(0, 15, 10, 15));
        
        for (String task : tasks) {
            JCheckBox checkBox = new JCheckBox(task);
            checkBox.setOpaque(false);
            checkBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            checkBox.setForeground(new Color(80, 80, 80));
            checkBox.setFocusPainted(false);
            checkBox.setIconTextGap(10);
            // Custom checkbox styling using FlatLaf properties for a softer look
            checkBox.putClientProperty(FlatClientProperties.STYLE, "icon.arc: 5");
            
            bodyPanel.add(checkBox);
            bodyPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        }
        
        card.add(bodyPanel, BorderLayout.CENTER);
        
        return card;
    }
}

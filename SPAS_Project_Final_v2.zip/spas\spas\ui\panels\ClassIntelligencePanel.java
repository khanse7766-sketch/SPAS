package com.spas.ui.panels;

import com.spas.db.DBManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ClassIntelligencePanel extends JPanel {
    private JPanel statsPanel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel chartPanel;

    // Direct references to the value labels inside each stat card.
    // Updating text goes straight through these fields - no need to walk
    // back up/down the component tree (that traversal is what caused the
    // ClassCastException: the old code looked at the wrong container).
    private JLabel highestMarksValueLabel;
    private JLabel lowestMarksValueLabel;
    private JLabel averageMarksValueLabel;
    private JLabel medianValueLabel;
    private JLabel passRateValueLabel;
    private JLabel failRateValueLabel;
    private JLabel topStudentsValueLabel;
    private JLabel totalStudentsValueLabel;

    public ClassIntelligencePanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        loadData();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Class Intelligence");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Updated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));

        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createStatisticsCards(), BorderLayout.NORTH);
        topPanel.add(createChartAndTablePanel(), BorderLayout.CENTER);

        content.add(topPanel, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createStatisticsCards() {
        statsPanel = new JPanel(new GridLayout(2, 4, 10, 10));

        highestMarksValueLabel = new JLabel("0");
        JPanel highestMarksCard = createStatCard("Highest Marks", highestMarksValueLabel, new Color(25, 145, 85));

        lowestMarksValueLabel = new JLabel("0");
        JPanel lowestMarksCard = createStatCard("Lowest Marks", lowestMarksValueLabel, new Color(220, 53, 69));

        averageMarksValueLabel = new JLabel("0");
        JPanel averageMarksCard = createStatCard("Average Marks", averageMarksValueLabel, new Color(47, 93, 255));

        medianValueLabel = new JLabel("0");
        JPanel medianCard = createStatCard("Median", medianValueLabel, new Color(255, 165, 0));

        passRateValueLabel = new JLabel("0%");
        JPanel passRateCard = createStatCard("Pass %", passRateValueLabel, new Color(25, 145, 85));

        failRateValueLabel = new JLabel("0%");
        JPanel failRateCard = createStatCard("Fail %", failRateValueLabel, new Color(220, 53, 69));

        topStudentsValueLabel = new JLabel("0");
        JPanel topStudentsCard = createStatCard("Top Students", topStudentsValueLabel, new Color(13, 110, 253));

        totalStudentsValueLabel = new JLabel("0");
        JPanel totalStudentsCard = createStatCard("Total Students", totalStudentsValueLabel, new Color(108, 117, 125));

        statsPanel.add(highestMarksCard);
        statsPanel.add(lowestMarksCard);
        statsPanel.add(averageMarksCard);
        statsPanel.add(medianCard);
        statsPanel.add(passRateCard);
        statsPanel.add(failRateCard);
        statsPanel.add(topStudentsCard);
        statsPanel.add(totalStudentsCard);

        return statsPanel;
    }

    /**
     * Builds a stat card around an already-created value label so the
     * caller keeps a direct reference to it. Returns a plain JPanel -
     * no JLabel-as-container wrapper trick, which is what led to the
     * wrong component being grabbed later.
     */
    private JPanel createStatCard(String title, JLabel valueLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    private JPanel createChartAndTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createTitledBorder("Class Performance Analysis"));

        chartPanel = new JPanel(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"Rank", "Roll No", "Student", "Average Marks", "GPA"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setAutoCreateRowSorter(true);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, chartPanel, new JScrollPane(table));
        split.setResizeWeight(0.4);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh = createStyledButton("Refresh Intelligence", new Color(47, 93, 255));
        refresh.addActionListener(e -> loadData());
        buttonPanel.add(refresh);

        panel.add(split, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));

        JLabel statusLabel = new JLabel("Ready | Click Refresh to update class intelligence data");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));

        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Class Intelligence Module"), BorderLayout.EAST);

        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(160, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void loadData() {
        tableModel.setRowCount(0);
        chartPanel.removeAll();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String q = "SELECT s.roll_no, u.full_name, COALESCE(AVG(m.quiz+m.assignment+m.midterm+m.final_exam), 0) avg_marks, COALESCE(AVG(ss.gpa), 0) gpa " +
                "FROM students s JOIN users u ON s.user_id=u.user_id " +
                "LEFT JOIN marks m ON s.student_id=m.student_id LEFT JOIN semester_summary ss ON s.student_id=ss.student_id " +
                "GROUP BY s.student_id, s.roll_no, u.full_name ORDER BY gpa DESC, avg_marks DESC";
        List<Double> marks = new ArrayList<>();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            int rank = 1;
            while (rs.next()) {
                double avg = rs.getDouble("avg_marks");
                double gpa = rs.getDouble("gpa");
                marks.add(avg);
                tableModel.addRow(new Object[]{rank++, rs.getString("roll_no"), rs.getString("full_name"), round(avg), round(gpa)});
                dataset.addValue(gpa, "GPA", rs.getString("roll_no"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load class intelligence: " + e.getMessage());
        }

        Collections.sort(marks);
        double highest = marks.isEmpty() ? 0 : marks.get(marks.size() - 1);
        double lowest = marks.isEmpty() ? 0 : marks.get(0);
        double average = marks.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double median = median(marks);
        int pass = 0;
        int fail = 0;
        for (double mark : marks) {
            if (mark >= 50) pass++; else fail++;
        }

        highestMarksValueLabel.setText(String.valueOf(round(highest)));
        lowestMarksValueLabel.setText(String.valueOf(round(lowest)));
        averageMarksValueLabel.setText(String.valueOf(round(average)));
        medianValueLabel.setText(String.valueOf(round(median)));
        passRateValueLabel.setText(marks.isEmpty() ? "0%" : round(pass * 100.0 / marks.size()) + "%");
        failRateValueLabel.setText(marks.isEmpty() ? "0%" : round(fail * 100.0 / marks.size()) + "%");
        topStudentsValueLabel.setText(String.valueOf(Math.min(10, tableModel.getRowCount())));
        totalStudentsValueLabel.setText(String.valueOf(tableModel.getRowCount()));

        chartPanel.add(new ChartPanel(ChartFactory.createBarChart("Class GPA Performance", "Student", "GPA", dataset)), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private double median(List<Double> values) {
        if (values.isEmpty()) return 0;
        int mid = values.size() / 2;
        if (values.size() % 2 == 1) return values.get(mid);
        return (values.get(mid - 1) + values.get(mid)) / 2.0;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
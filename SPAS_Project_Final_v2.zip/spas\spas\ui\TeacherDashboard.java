package com.spas.ui;

import com.formdev.flatlaf.FlatClientProperties;
import com.spas.auth.LoginFrame;
import com.spas.auth.SessionManager;
import com.spas.ui.panels.MarksManagementPanel;
import com.spas.ui.panels.AttendanceManagementPanel;
import com.spas.ui.panels.ReportsPanel;
import com.spas.ui.panels.TeacherHomePanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class TeacherDashboard extends JFrame {

    private JPanel contentPanel;
    private CardLayout cardLayout;
    private Map<String, JPanel> cards = new LinkedHashMap<>();

    public TeacherDashboard() {
        setTitle("SPAS - Teacher Planner");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Root container with the warm off-white background
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(new Color(250, 246, 235));
        
        // Top Bar (Welcome & Logout)
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        JLabel welcomeLabel = new JLabel("Welcome!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        welcomeLabel.putClientProperty(FlatClientProperties.STYLE, "background: #DCAEF5; padding: 5,15,5,15; arc: 15");
        welcomeLabel.setOpaque(true);
        topBar.add(welcomeLabel, BorderLayout.WEST);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 15; background: #E0E0E0");
        logoutBtn.addActionListener(e -> {
            SessionManager.getInstance().logout();
            dispose();
            new LoginFrame().setVisible(true);
        });
        topBar.add(logoutBtn, BorderLayout.EAST);
        
        rootPanel.add(topBar, BorderLayout.NORTH);

        // --- SIDEBAR (Folder Tabs) ---
        JPanel sidebarWrapper = new JPanel(new BorderLayout());
        sidebarWrapper.setOpaque(false);
        sidebarWrapper.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setOpaque(false);
        sidebar.setBorder(new EmptyBorder(20, 0, 20, 0)); // No left/right padding so tabs touch edges
        
        // --- CONTENT AREA ---
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false);
        contentPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        
        // Setup Panels
        cards.put("To-Do Lists", new TeacherHomePanel());
        cards.put("Marks Entry", new MarksManagementPanel());
        cards.put("Attendance Entry", new AttendanceManagementPanel());
        cards.put("Reports", new ReportsPanel());
        
        for (Map.Entry<String, JPanel> entry : cards.entrySet()) {
            contentPanel.add(entry.getValue(), entry.getKey());
        }

        // Add Folder Tabs
        addFolderTab(sidebar, "BOOKMARKS", new Color(245, 110, 145), null); // Decorative
        addFolderTab(sidebar, "WEEKLY FOCUS", new Color(245, 165, 55), null); // Decorative
        addFolderTab(sidebar, "TO-DO LISTS", new Color(255, 235, 85), "To-Do Lists"); // Main
        addFolderTab(sidebar, "CALENDAR", new Color(175, 225, 95), "Marks Entry"); // Mapped to Marks
        addFolderTab(sidebar, "MEETINGS", new Color(110, 215, 210), "Attendance Entry"); // Mapped to Attendance
        addFolderTab(sidebar, "IDEAS", new Color(150, 200, 255), "Reports"); // Mapped to Reports
        addFolderTab(sidebar, "HOME", new Color(180, 100, 245), "To-Do Lists");
        
        sidebarWrapper.add(sidebar, BorderLayout.NORTH);
        rootPanel.add(sidebarWrapper, BorderLayout.WEST);
        rootPanel.add(contentPanel, BorderLayout.CENTER);
        
        setContentPane(rootPanel);
        
        // Show default
        cardLayout.show(contentPanel, "To-Do Lists");
    }
    
    private void addFolderTab(JPanel sidebar, String title, Color bgColor, String targetCard) {
        JButton tab = new JButton(title);
        tab.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tab.setForeground(Color.BLACK);
        tab.setBackground(bgColor);
        tab.setFocusPainted(false);
        tab.setCursor(new Cursor(Cursor.HAND_CURSOR));
        tab.setHorizontalAlignment(SwingConstants.LEFT);
        
        // Make it look like a physical tab by rounding top-right and bottom-right corners only
        tab.putClientProperty(FlatClientProperties.STYLE, "arc: 0; margin: 15,20,15,40; borderWidth: 0; border: 0,0,0,0");
        
        // FlatLaf doesn't easily let us round *only* right corners with standard properties without custom borders,
        // so we will just round it normally and give it a slight margin to look like a tab sticking out.
        tab.putClientProperty(FlatClientProperties.STYLE, "arc: 15; margin: 15,10,15,30; borderWidth: 0");
        
        // But to make them stack without gaps like the image, we remove Y spacing.
        // We'll wrap the button in a panel to control its width and right-side alignment.
        JPanel tabWrapper = new JPanel(new BorderLayout());
        tabWrapper.setOpaque(false);
        tabWrapper.setBorder(new EmptyBorder(1, 0, 1, 0)); // 1px gap between tabs
        tabWrapper.add(tab, BorderLayout.CENTER);
        
        // Set fixed width so they align perfectly
        tabWrapper.setMaximumSize(new Dimension(180, 50));
        tabWrapper.setPreferredSize(new Dimension(180, 50));
        
        if (targetCard != null) {
            tab.addActionListener(e -> cardLayout.show(contentPanel, targetCard));
        }
        
        sidebar.add(tabWrapper);
    }
}

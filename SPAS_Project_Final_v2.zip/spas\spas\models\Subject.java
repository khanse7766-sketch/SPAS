package com.spas.models;

public class Subject {
    private int subjectId;
    private String subjectCode;
    private String name;
    private int creditHours;
    private int semester;

    public Subject(int subjectId, String subjectCode, String name, int creditHours, int semester) {
        this.subjectId = subjectId;
        this.subjectCode = subjectCode;
        this.name = name;
        this.creditHours = creditHours;
        this.semester = semester;
    }

    public int getSubjectId() { return subjectId; }
    public String getSubjectCode() { return subjectCode; }
    public String getName() { return name; }
    public int getCreditHours() { return creditHours; }
    public int getSemester() { return semester; }
    
    @Override
    public String toString() {
        return subjectCode + " - " + name;
    }
}

package com.spas.logic;

public class StrategyGenerator {
    
    /**
     * Back-calculates required average score to reach a target CGPA.
     * Simplified linear estimation for demonstration.
     */
    public static String generateStrategy(double currentCgpa, int currentSem, double targetCgpa) {
        if (currentSem >= 8) return "Already in final semester.";
        if (targetCgpa <= currentCgpa) return "Target is lower than current CGPA. Maintain current performance.";
        
        int remainingSems = 8 - currentSem;
        // Formula: Target = (Current * CurrentSem + Required * RemainingSem) / 8
        double requiredTotal = (targetCgpa * 8) - (currentCgpa * currentSem);
        double requiredPerSem = requiredTotal / remainingSems;
        
        if (requiredPerSem > 4.0) {
            return String.format("Target %.2f is mathematically impossible (Requires %.2f GPA per remaining semester).", targetCgpa, requiredPerSem);
        } else {
            return String.format("To reach %.2f CGPA, you must average %.2f GPA in each of your remaining %d semesters.", targetCgpa, requiredPerSem, remainingSems);
        }
    }
}

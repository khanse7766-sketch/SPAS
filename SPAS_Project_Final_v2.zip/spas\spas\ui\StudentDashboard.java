package com.spas.ui;

import javax.swing.*;

public class StudentDashboard extends BaseDashboard {

    public StudentDashboard() {
        super("Student Dashboard");
        setSize(1300, 850);
        setLocationRelativeTo(null);
        if (contentPanel.getComponentCount() > 0) {
            cardLayout.show(contentPanel, "Home");
        }
    }

    @Override
    protected void setupSidebar() {
        addSidebarItem("Home", new com.spas.ui.panels.StudentAnalyticsPanel());
        addSidebarItem("My Profile", createDummyPanel("Profile"));
        addSidebarItem("My Marks", createDummyPanel("Marks View"));
        addSidebarItem("My Attendance", createDummyPanel("Attendance View"));
        addSidebarItem("My Rank & DNA", createDummyPanel("Explainable Ranking & DNA Profile"));
        addSidebarItem("Trend Analytics", createDummyPanel("Trend Analytics"));
        addSidebarItem("Digital Twin", createDummyPanel("Academic Digital Twin (Prediction)"));
        addSidebarItem("What-If Simulator", createDummyPanel("What-If Simulator"));
        addSidebarItem("Strategy Generator", createDummyPanel("Semester Strategy Generator"));
    }

    private JPanel createDummyPanel(String text) {
        JPanel p = new JPanel();
        p.add(new JLabel(text));
        return p;
    }
}

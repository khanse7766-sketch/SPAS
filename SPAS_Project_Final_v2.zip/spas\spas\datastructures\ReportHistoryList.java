package com.spas.datastructures;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom Linked List for storing report history (Append-only).
 */
public class ReportHistoryList {
    private ReportHistoryNode head;
    private ReportHistoryNode tail;
    private int size;

    public ReportHistoryList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    public void append(String reportType, String reportOutput, Timestamp generatedAt) {
        ReportHistoryNode newNode = new ReportHistoryNode(reportType, reportOutput, generatedAt);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            tail = newNode;
        }
        size++;
    }

    public List<ReportHistoryNode> traverse() {
        List<ReportHistoryNode> list = new ArrayList<>();
        ReportHistoryNode current = head;
        while (current != null) {
            list.add(current);
            current = current.getNext();
        }
        return list;
    }
}

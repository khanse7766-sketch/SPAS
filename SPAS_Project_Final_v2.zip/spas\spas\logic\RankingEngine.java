package com.spas.logic;

import com.spas.models.Student;

public class RankingEngine {

    // Helper class to hold student and score
    public static class RankedStudent {
        public Student student;
        public double score;

        public RankedStudent(Student student, double score) {
            this.student = student;
            this.score = score;
        }
    }

    /**
     * Sorts the array of ranked students using manual QuickSort (O(n log n)).
     * Sorts in descending order (highest score first).
     */
    public static void sortDescending(RankedStudent[] arr) {
        if (arr == null || arr.length <= 1) return;
        quickSort(arr, 0, arr.length - 1);
    }

    private static void quickSort(RankedStudent[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static int partition(RankedStudent[] arr, int low, int high) {
        double pivot = arr[high].score;
        int i = (low - 1); // index of smaller element

        for (int j = low; j < high; j++) {
            // For descending order, we check if current is GREATER than pivot
            if (arr[j].score > pivot) {
                i++;
                // swap arr[i] and arr[j]
                RankedStudent temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        // swap arr[i+1] and arr[high] (or pivot)
        RankedStudent temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }
}

package com.spas.ui.panels;

import com.spas.auth.SessionManager;
import com.spas.db.DBManager;
import com.spas.logic.SearchEngine;
import com.spas.models.Student;
import com.spas.models.User;
import com.spas.validation.Validator;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentManagementPanel extends JPanel {
    private JTextField txtName;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JTextField txtRollNo;
    private JTextField txtBatch;
    private JPasswordField txtPassword;
    private JSpinner spSemester;
    private JLabel lblPhoto;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private Student[] currentStudentsArray = new Student[0];
    private String photoPath = "";
    private int selectedStudentId = -1;
    private int selectedUserId = -1;

    public StudentManagementPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Student Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JPanel topPanel = new JPanel(new BorderLayout(0, 8));
        topPanel.add(title, BorderLayout.NORTH);
        topPanel.add(createFormPanel(), BorderLayout.CENTER);
        topPanel.add(createSearchPanel(), BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        String[] columns = {"ID", "User ID", "Name", "Roll No", "Batch", "Semester", "Email", "Phone", "Photo"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::handleRowSelection);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData(false);
    }

    private JPanel createFormPanel() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 5, 3, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        txtName = new JTextField(14);
        txtEmail = new JTextField(14);
        txtPhone = new JTextField(14);
        txtRollNo = new JTextField(10);
        txtBatch = new JTextField(10);
        txtPassword = new JPasswordField(10);
        spSemester = new JSpinner(new SpinnerNumberModel(1, 1, 8, 1));
        lblPhoto = new JLabel("No photo selected");

        addField(form, gbc, 0, "Name", txtName);
        addField(form, gbc, 1, "Email", txtEmail);
        addField(form, gbc, 2, "Phone", txtPhone);
        addField(form, gbc, 3, "Roll No", txtRollNo);
        addField(form, gbc, 4, "Batch", txtBatch);
        addField(form, gbc, 5, "Semester", spSemester);
        addField(form, gbc, 6, "Password", txtPassword);

        JButton photoBtn = new JButton("Upload Photo");
        photoBtn.addActionListener(e -> choosePhoto());
        gbc.gridx = 0;
        gbc.gridy = 7;
        form.add(photoBtn, gbc);
        gbc.gridx = 1;
        form.add(lblPhoto, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        JButton refreshBtn = new JButton("Refresh");
        addBtn.addActionListener(e -> addStudent());
        updateBtn.addActionListener(e -> updateStudent());
        deleteBtn.addActionListener(e -> deleteStudent());
        clearBtn.addActionListener(e -> clearForm());
        refreshBtn.addActionListener(e -> loadData(true));
        buttons.add(addBtn);
        buttons.add(updateBtn);
        buttons.add(deleteBtn);
        buttons.add(clearBtn);
        buttons.add(refreshBtn);

        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        form.add(buttons, gbc);
        return form;
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(15);
        JButton searchBtn = new JButton("Search");
        JButton refreshBtn = new JButton("Refresh");
        searchBtn.addActionListener(e -> performBinarySearch());
        refreshBtn.addActionListener(e -> loadData(true));
        searchPanel.add(new JLabel("Roll No:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);
        return searchPanel;
    }

    private void addField(JPanel form, GridBagConstraints gbc, int row, String label, JComponent field) {
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = row;
        form.add(new JLabel(label + ":"), gbc);
        gbc.gridx = 1;
        form.add(field, gbc);
    }

    private void choosePhoto() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File selected = chooser.getSelectedFile();
            if (!Validator.isValidPhoto(selected.getName())) {
                JOptionPane.showMessageDialog(this, "Select a JPG, JPEG, or PNG photo.");
                return;
            }
            photoPath = selected.getAbsolutePath();
            lblPhoto.setText(selected.getName());
        }
    }

    private void loadData(boolean showMessage) {
        tableModel.setRowCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Database connection is not available.");
            return;
        }

        List<Student> list = new ArrayList<>();
        String q = "SELECT s.student_id, s.user_id, s.roll_no, s.batch, s.current_semester, s.photo_path, " +
                "u.full_name, u.email, u.phone FROM students s JOIN users u ON s.user_id = u.user_id " +
                "ORDER BY s.roll_no";

        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Student st = new Student(
                        rs.getInt("student_id"),
                        rs.getInt("user_id"),
                        rs.getString("roll_no"),
                        rs.getString("batch"),
                        rs.getInt("current_semester"),
                        rs.getString("photo_path"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("phone")
                );
                list.add(st);
                tableModel.addRow(new Object[]{
                        st.getStudentId(), st.getUserId(), st.getFullName(), st.getRollNo(), st.getBatch(),
                        st.getCurrentSemester(), st.getEmail(), st.getPhone(), st.getPhotoPath()
                });
            }
            currentStudentsArray = list.toArray(new Student[0]);
            SearchEngine.sortStudentsByRollNo(currentStudentsArray);
            if (showMessage) {
                JOptionPane.showMessageDialog(this, "Students loaded: " + currentStudentsArray.length);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage());
        }
    }

    private void addStudent() {
        if (!validateForm(true)) return;
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String insertUser = "INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'STUDENT')";
        String insertStudent = "INSERT INTO students (user_id, roll_no, batch, current_semester, photo_path) VALUES (?, ?, ?, ?, ?)";

        try {
            conn.setAutoCommit(false);
            int userId;
            try (PreparedStatement userStmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS)) {
                userStmt.setString(1, txtName.getText().trim());
                userStmt.setString(2, txtEmail.getText().trim());
                userStmt.setString(3, txtPhone.getText().trim());
                userStmt.setString(4, BCrypt.hashpw(new String(txtPassword.getPassword()), BCrypt.gensalt()));
                userStmt.executeUpdate();
                try (ResultSet keys = userStmt.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Could not create user record.");
                    userId = keys.getInt(1);
                }
            }

            int studentId;
            try (PreparedStatement studentStmt = conn.prepareStatement(insertStudent, Statement.RETURN_GENERATED_KEYS)) {
                studentStmt.setInt(1, userId);
                studentStmt.setString(2, txtRollNo.getText().trim());
                studentStmt.setString(3, txtBatch.getText().trim());
                studentStmt.setInt(4, (Integer) spSemester.getValue());
                studentStmt.setString(5, photoPath.isBlank() ? null : photoPath);
                studentStmt.executeUpdate();
                try (ResultSet keys = studentStmt.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Could not create student record.");
                    studentId = keys.getInt(1);
                }
            }

            logAction(conn, "INSERT", "students", studentId, "", txtRollNo.getText().trim());
            conn.commit();
            JOptionPane.showMessageDialog(this, "Student added successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            rollback(conn);
            JOptionPane.showMessageDialog(this, "Could not add student: " + e.getMessage());
        } finally {
            restoreAutoCommit(conn);
        }
    }

    private void updateStudent() {
        if (selectedStudentId < 0 || selectedUserId < 0) {
            JOptionPane.showMessageDialog(this, "Select a student from the table first.");
            return;
        }
        if (!validateForm(false)) return;

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String updateUser = "UPDATE users SET full_name=?, email=?, phone=? WHERE user_id=?";
        String updateStudent = "UPDATE students SET roll_no=?, batch=?, current_semester=?, photo_path=? WHERE student_id=?";

        try {
            conn.setAutoCommit(false);
            try (PreparedStatement userStmt = conn.prepareStatement(updateUser)) {
                userStmt.setString(1, txtName.getText().trim());
                userStmt.setString(2, txtEmail.getText().trim());
                userStmt.setString(3, txtPhone.getText().trim());
                userStmt.setInt(4, selectedUserId);
                userStmt.executeUpdate();
            }
            try (PreparedStatement studentStmt = conn.prepareStatement(updateStudent)) {
                studentStmt.setString(1, txtRollNo.getText().trim());
                studentStmt.setString(2, txtBatch.getText().trim());
                studentStmt.setInt(3, (Integer) spSemester.getValue());
                studentStmt.setString(4, photoPath.isBlank() ? null : photoPath);
                studentStmt.setInt(5, selectedStudentId);
                studentStmt.executeUpdate();
            }
            logAction(conn, "UPDATE", "students", selectedStudentId, "", txtRollNo.getText().trim());
            conn.commit();
            JOptionPane.showMessageDialog(this, "Student updated successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            rollback(conn);
            JOptionPane.showMessageDialog(this, "Could not update student: " + e.getMessage());
        } finally {
            restoreAutoCommit(conn);
        }
    }

    private void deleteStudent() {
        if (selectedStudentId < 0 || selectedUserId < 0) {
            JOptionPane.showMessageDialog(this, "Select a student from the table first.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Delete selected student?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) return;

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try {
            conn.setAutoCommit(false);
            logAction(conn, "DELETE", "students", selectedStudentId, txtRollNo.getText().trim(), "");
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM users WHERE user_id=?")) {
                stmt.setInt(1, selectedUserId);
                stmt.executeUpdate();
            }
            conn.commit();
            JOptionPane.showMessageDialog(this, "Student deleted successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            rollback(conn);
            JOptionPane.showMessageDialog(this, "Could not delete student: " + e.getMessage());
        } finally {
            restoreAutoCommit(conn);
        }
    }

    private boolean validateForm(boolean requirePassword) {
        String password = new String(txtPassword.getPassword());
        if (!Validator.isValidName(txtName.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Enter a valid name.");
            return false;
        }
        if (!Validator.isValidEmail(txtEmail.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Enter a valid email.");
            return false;
        }
        if (!Validator.isValidPhone(txtPhone.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Phone must use the 03XXXXXXXXX format.");
            return false;
        }
        if (!Validator.isValidRollNo(txtRollNo.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Enter a valid roll number.");
            return false;
        }
        if (txtBatch.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter batch.");
            return false;
        }
        if (!Validator.isValidSemester((Integer) spSemester.getValue())) {
            JOptionPane.showMessageDialog(this, "Semester must be between 1 and 8.");
            return false;
        }
        if (requirePassword && !Validator.isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters and include an uppercase letter and a digit.");
            return false;
        }
        return true;
    }

    private void performBinarySearch() {
        String target = searchField.getText().trim();
        if (target.isEmpty()) {
            loadData(false);
            return;
        }
        Student found = SearchEngine.binarySearchByRollNo(currentStudentsArray, target);
        tableModel.setRowCount(0);
        if (found != null) {
            tableModel.addRow(new Object[]{
                    found.getStudentId(), found.getUserId(), found.getFullName(), found.getRollNo(), found.getBatch(),
                    found.getCurrentSemester(), found.getEmail(), found.getPhone(), found.getPhotoPath()
            });
        } else {
            JOptionPane.showMessageDialog(this, "Student not found.");
            loadData(false);
        }
    }

    private void handleRowSelection(ListSelectionEvent event) {
        if (event.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
        int row = table.convertRowIndexToModel(table.getSelectedRow());
        selectedStudentId = (Integer) tableModel.getValueAt(row, 0);
        selectedUserId = (Integer) tableModel.getValueAt(row, 1);
        txtName.setText(value(row, 2));
        txtRollNo.setText(value(row, 3));
        txtBatch.setText(value(row, 4));
        spSemester.setValue((Integer) tableModel.getValueAt(row, 5));
        txtEmail.setText(value(row, 6));
        txtPhone.setText(value(row, 7));
        photoPath = value(row, 8);
        lblPhoto.setText(photoPath.isBlank() ? "No photo selected" : new File(photoPath).getName());
        txtPassword.setText("");
    }

    private String value(int row, int col) {
        Object value = tableModel.getValueAt(row, col);
        return value == null ? "" : value.toString();
    }

    private void clearForm() {
        selectedStudentId = -1;
        selectedUserId = -1;
        photoPath = "";
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtRollNo.setText("");
        txtBatch.setText("");
        txtPassword.setText("");
        spSemester.setValue(1);
        lblPhoto.setText("No photo selected");
        table.clearSelection();
    }

    private void logAction(Connection conn, String actionType, String tableName, int recordId, String oldValue, String newValue) throws SQLException {
        User user = SessionManager.getInstance().getCurrentUser();
        String q = "INSERT INTO action_log (action_type, table_name, record_id, old_value, new_value, performed_by) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setString(1, actionType);
            stmt.setString(2, tableName);
            stmt.setInt(3, recordId);
            stmt.setString(4, oldValue);
            stmt.setString(5, newValue);
            if (user == null) {
                stmt.setNull(6, Types.INTEGER);
            } else {
                stmt.setInt(6, user.getUserId());
            }
            stmt.executeUpdate();
        }
    }

    private void rollback(Connection conn) {
        try {
            conn.rollback();
        } catch (SQLException ignored) {
        }
    }

    private void restoreAutoCommit(Connection conn) {
        try {
            conn.setAutoCommit(true);
        } catch (SQLException ignored) {
        }
    }
}

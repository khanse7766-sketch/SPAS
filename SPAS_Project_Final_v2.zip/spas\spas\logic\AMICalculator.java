package com.spas.logic;

public class AMICalculator {

    /**
     * Calculates Academic Momentum Index (AMI).
     * AMI = 0.30 * GPA_Trend + 0.30 * Attendance_Trend + 0.20 * Consistency + 0.20 * Improvement
     * Normalized 0-100 score.
     */
    public static double calculateAMI(double gpaTrendNormalized, double attendanceTrendNormalized, double consistencyScore, double improvementScore) {
        double ami = (0.30 * gpaTrendNormalized) + 
                     (0.30 * attendanceTrendNormalized) + 
                     (0.20 * consistencyScore) + 
                     (0.20 * improvementScore);
        
        return Math.max(0, Math.min(100, ami));
    }
    
    public static String getAMIStatus(double amiScore) {
        if (amiScore >= 75) return "High Momentum";
        if (amiScore >= 50) return "Moderate Momentum";
        return "Low Momentum";
    }
}

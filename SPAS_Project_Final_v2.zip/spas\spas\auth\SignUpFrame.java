package com.spas.auth;

import com.formdev.flatlaf.FlatClientProperties;
import com.spas.db.DBManager;
import com.spas.ui.theme.ThemeManager;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class SignUpFrame extends JFrame {
    private JTextField nameField, emailField, phoneField;
    private JPasswordField passwordField;
    private JComboBox<String> roleCombo;
    private JButton signUpBtn, themeToggleBtn;
    private JLabel errorLabel;

    public SignUpFrame() {
        setTitle("SPAS - Sign Up");
        setSize(550, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        ThemeManager.initializeTheme();
        initUI();
    }

    private void initUI() {
        JPanel container = new JPanel(new BorderLayout());
        container.putClientProperty(FlatClientProperties.STYLE, "background: $Panel.background");

        // Top bar for theme toggle
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topPanel.setOpaque(false);
        themeToggleBtn = new JButton(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
        themeToggleBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 10; borderWidth: 0; focusWidth: 0;");
        themeToggleBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        themeToggleBtn.addActionListener(e -> {
            ThemeManager.toggleTheme();
            themeToggleBtn.setText(ThemeManager.isDarkMode() ? "☀️ Light" : "🌙 Dark");
            SwingUtilities.updateComponentTreeUI(this);
        });
        topPanel.add(themeToggleBtn);
        container.add(topPanel, BorderLayout.NORTH);

        // Main content
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setOpaque(false);
        mainPanel.setBorder(new EmptyBorder(10, 40, 40, 40));

        // Title
        JLabel titleLabel = new JLabel("Create an Account");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Subtitle
        JPanel subtitlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        subtitlePanel.setOpaque(false);
        JLabel subtitleLabel = new JLabel("Already have an account?");
        subtitleLabel.setForeground(Color.GRAY);
        JLabel signInLabel = new JLabel("Sign In");
        signInLabel.setForeground(new Color(47, 93, 255));
        signInLabel.setFont(signInLabel.getFont().deriveFont(Font.BOLD));
        signInLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signInLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });
        subtitlePanel.add(subtitleLabel);
        subtitlePanel.add(signInLabel);
        mainPanel.add(subtitlePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Full Name Field
        nameField = new JTextField();
        nameField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Full Name");
        nameField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        nameField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(nameField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Email Field
        emailField = new JTextField();
        emailField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Email Address");
        emailField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        emailField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(emailField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Phone Field
        phoneField = new JTextField();
        phoneField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Phone Number");
        phoneField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        phoneField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(phoneField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Role Selector
        roleCombo = new JComboBox<>(new String[]{"STUDENT", "TEACHER", "ADMIN"});
        roleCombo.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10;");
        roleCombo.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(roleCombo);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Password Field
        passwordField = new JPasswordField();
        passwordField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Password");
        passwordField.putClientProperty(FlatClientProperties.STYLE, "arc: 10; margin: 5,10,5,10; showRevealButton: true;");
        passwordField.setMaximumSize(new Dimension(500, 40));
        mainPanel.add(passwordField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Error/Success Label
        errorLabel = new JLabel(" ");
        errorLabel.setForeground(new Color(220, 53, 69)); // Red
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        errorLabel.setVisible(false);
        mainPanel.add(errorLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Sign Up Button
        signUpBtn = new JButton("Create Account");
        signUpBtn.setBackground(new Color(24, 119, 242));
        signUpBtn.setForeground(Color.WHITE);
        signUpBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        signUpBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 10; borderWidth: 0; focusWidth: 0;");
        signUpBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signUpBtn.setMaximumSize(new Dimension(500, 45));
        signUpBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(signUpBtn);

        signUpBtn.addActionListener(e -> attemptSignUp());

        container.add(mainPanel, BorderLayout.CENTER);
        add(container);
    }

    private void attemptSignUp() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = roleCombo.getSelectedItem().toString();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showMsg("Name, Email, and Password are required.", false);
            return;
        }

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            showMsg("Database connection error.", false);
            return;
        }

        try {
            // Check if email exists
            String checkQ = "SELECT user_id FROM users WHERE email = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQ);
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                showMsg("An account with this email already exists.", false);
                return;
            }

            // Insert User
            String q = "INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(q, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.setString(4, BCrypt.hashpw(password, BCrypt.gensalt()));
            stmt.setString(5, role);
            stmt.executeUpdate();

            int userId = -1;
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) userId = keys.getInt(1);
            }

            // If Student, create a dummy student record
            if ("STUDENT".equals(role) && userId != -1) {
                String sq = "INSERT INTO students (user_id, roll_no, batch, current_semester) VALUES (?, ?, ?, ?)";
                PreparedStatement sStmt = conn.prepareStatement(sq);
                sStmt.setInt(1, userId);
                sStmt.setString(2, "TEMP-" + userId);
                sStmt.setString(3, "Batch-TEMP");
                sStmt.setInt(4, 1);
                sStmt.executeUpdate();
            }

            showMsg("Account created successfully! You can now log in.", true);
            signUpBtn.setEnabled(false);
            
            // Redirect to login after short delay
            Timer timer = new Timer(1500, e -> {
                new LoginFrame().setVisible(true);
                dispose();
            });
            timer.setRepeats(false);
            timer.start();

        } catch (Exception e) {
            showMsg("An error occurred during registration.", false);
            e.printStackTrace();
        }
    }

    private void showMsg(String msg, boolean isSuccess) {
        errorLabel.setForeground(isSuccess ? new Color(40, 167, 69) : new Color(220, 53, 69));
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }
}

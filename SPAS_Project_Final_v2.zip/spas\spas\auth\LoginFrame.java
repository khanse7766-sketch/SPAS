package com.spas.auth;

import com.formdev.flatlaf.FlatClientProperties;
import com.spas.db.DBManager;
import com.spas.models.User;
import com.spas.ui.AdminDashboard;
import com.spas.ui.StudentDashboard;
import com.spas.ui.TeacherDashboard;
import com.spas.ui.theme.ThemeManager;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginFrame extends JFrame {

    public LoginFrame() {
        setTitle("SPAS - Login Portal");
        setSize(1200, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        ThemeManager.initializeTheme();
        initUI();
    }

    private void initUI() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(new Color(245, 246, 250)); // Light grey background
        
        // --- TOP TITLE ---
        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setBorder(new EmptyBorder(30, 0, 30, 0));
        JLabel titleLabel = new JLabel("Shifa Tameer-e-Millat Portal");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titleLabel.setForeground(new Color(80, 60, 150)); // Dark purple
        titlePanel.add(titleLabel);
        
        rootPanel.add(titlePanel, BorderLayout.NORTH);
        
        // --- 3 COLUMN CARDS ---
        JPanel cardsContainer = new JPanel(new GridBagLayout());
        cardsContainer.setOpaque(false);
        
        JPanel gridPanel = new JPanel(new GridLayout(1, 3, 40, 0));
        gridPanel.setOpaque(false);
        
        // 1. Admin Card
        gridPanel.add(createRoleCard("ADMIN PORTAL", "[Admin]", "👨🏻‍💼", "Admin", 
                new Color(92, 75, 175), Color.WHITE, new Color(30, 30, 45), Color.WHITE));
                
        // 2. Teacher Card
        gridPanel.add(createRoleCard("TEACHER PORTAL", "[Teacher]", "👨🏻‍🏫", "Teacher", 
                new Color(252, 195, 31), Color.BLACK, new Color(30, 30, 45), Color.WHITE));
                
        // 3. Student Card
        gridPanel.add(createRoleCard("STUDENT PORTAL", "[Student]", "📖", "Student", 
                Color.WHITE, Color.BLACK, new Color(252, 195, 31), Color.BLACK));
                
        cardsContainer.add(gridPanel);
        rootPanel.add(cardsContainer, BorderLayout.CENTER);
        
        setContentPane(rootPanel);
    }
    
    private JPanel createRoleCard(String portalName, String roleTag, String avatar, String roleName, 
                                  Color bgColor, Color fgColor, Color btnBgColor, Color btnFgColor) {
                                      
        JPanel cardWrapper = new JPanel(new BorderLayout());
        cardWrapper.setOpaque(false);
        cardWrapper.setPreferredSize(new Dimension(320, 650));
        
        // Main Card panel
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(bgColor);
        card.putClientProperty(FlatClientProperties.STYLE, "arc: 25");
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        if (bgColor.equals(Color.WHITE)) {
            // Add subtle border for white card
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                    new EmptyBorder(20, 20, 20, 20)
            ));
        }
        
        // TOP SECTION
        JPanel topSection = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topSection.setOpaque(false);
        JLabel portalLabel = new JLabel(portalName + " ");
        portalLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        portalLabel.setForeground(fgColor);
        
        JLabel tagLabel = new JLabel(roleTag);
        tagLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        tagLabel.setForeground(bgColor.equals(Color.WHITE) ? Color.WHITE : Color.BLACK);
        tagLabel.setOpaque(true);
        tagLabel.setBackground(bgColor.equals(Color.WHITE) ? Color.BLACK : Color.WHITE);
        tagLabel.setBorder(new EmptyBorder(2, 5, 2, 5));
        tagLabel.putClientProperty(FlatClientProperties.STYLE, "arc: 5");
        
        topSection.add(portalLabel);
        topSection.add(tagLabel);
        
        // AVATAR
        JLabel avatarLabel = new JLabel(avatar);
        avatarLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 80));
        avatarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // WELCOME TEXT
        JLabel welcomeLabel = new JLabel("Welcome, " + roleName);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        welcomeLabel.setForeground(fgColor);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel accessLabel = new JLabel("access your Educora " + roleName.toLowerCase() + " portal");
        accessLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        accessLabel.setForeground(fgColor);
        accessLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // MIDDLE WHITE SECTION (Inputs)
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.setBackground(Color.WHITE);
        inputPanel.putClientProperty(FlatClientProperties.STYLE, "arc: 20");
        inputPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        JTextField emailField = new JTextField();
        emailField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Email Address");
        emailField.putClientProperty(FlatClientProperties.STYLE, "border: 0,0,1,0; margin: 10,0,10,0; background: null");
        emailField.setMaximumSize(new Dimension(300, 40));
        
        JPasswordField passwordField = new JPasswordField();
        passwordField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Password");
        passwordField.putClientProperty(FlatClientProperties.STYLE, "border: 0,0,1,0; margin: 10,0,10,0; background: null; showRevealButton: true");
        passwordField.setMaximumSize(new Dimension(300, 40));
        
        JButton loginBtn = new JButton(roleName + " Login");
        loginBtn.setBackground(btnBgColor);
        loginBtn.setForeground(btnFgColor);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginBtn.putClientProperty(FlatClientProperties.STYLE, "arc: 20; borderWidth: 0; focusWidth: 0;");
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.setMaximumSize(new Dimension(300, 45));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel errorLabel = new JLabel(" ");
        errorLabel.setForeground(Color.RED);
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel forgotLabel = new JLabel("Forgot Password?");
        forgotLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        forgotLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        forgotLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new ForgotPasswordFrame().setVisible(true);
                dispose();
            }
        });
        
        inputPanel.add(emailField);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        inputPanel.add(passwordField);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        inputPanel.add(errorLabel);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        inputPanel.add(loginBtn);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        inputPanel.add(forgotLabel);
        
        // BOTTOM SECTION (Socials & Terms)
        JPanel socialPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        socialPanel.setOpaque(false);
        
        JButton fbBtn = createSocialButton("f  FB", new Color(66, 103, 178), Color.WHITE);
        JButton googleBtn = createSocialButton("G  Google", Color.WHITE, Color.BLACK);
        socialPanel.add(fbBtn);
        socialPanel.add(googleBtn);
        
        JLabel termsLabel1 = new JLabel("Terms & Conditions, Privacy policy and");
        termsLabel1.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        termsLabel1.setForeground(fgColor);
        termsLabel1.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel termsLabel2 = new JLabel("Acceran policy.");
        termsLabel2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        termsLabel2.setForeground(fgColor);
        termsLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Login Action
        loginBtn.addActionListener(e -> attemptLogin(roleName.toUpperCase(), emailField.getText(), new String(passwordField.getPassword()), errorLabel));
        passwordField.addActionListener(e -> attemptLogin(roleName.toUpperCase(), emailField.getText(), new String(passwordField.getPassword()), errorLabel));
        
        // Add to card
        card.add(topSection);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(avatarLabel);
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(welcomeLabel);
        card.add(accessLabel);
        card.add(Box.createRigidArea(new Dimension(0, 25)));
        card.add(inputPanel);
        card.add(Box.createRigidArea(new Dimension(0, 25)));
        card.add(socialPanel);
        card.add(Box.createRigidArea(new Dimension(0, 15)));
        card.add(termsLabel1);
        card.add(termsLabel2);
        
        cardWrapper.add(card, BorderLayout.CENTER);
        return cardWrapper;
    }
    
    private JButton createSocialButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.putClientProperty(FlatClientProperties.STYLE, "arc: 20; borderWidth: 0; padding: 5,15,5,15");
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Make mock buttons just show a message
        btn.addActionListener(e -> JOptionPane.showMessageDialog(this, "Social login is a mockup for demonstration purposes."));
        return btn;
    }

    private void attemptLogin(String role, String email, String password, JLabel errorLabel) {
        if (email.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please fill all fields.");
            return;
        }

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            errorLabel.setText("Database connection error.");
            return;
        }

        try {
            // Fetch user by email AND role
            String q = "SELECT user_id, full_name, email, phone, role, password_hash, failed_attempts, locked_until FROM users WHERE email = ? AND role = ?";
            PreparedStatement stmt = conn.prepareStatement(q);
            stmt.setString(1, email.trim());
            stmt.setString(2, role);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Check Lock Status
                java.sql.Timestamp lockedUntil = rs.getTimestamp("locked_until");
                if (lockedUntil != null && lockedUntil.after(new java.util.Date())) {
                    errorLabel.setText("Account locked. Try again later.");
                    return;
                }

                String hash = rs.getString("password_hash");
                if (BCrypt.checkpw(password, hash)) {
                    // Success! Reset attempts
                    int userId = rs.getInt("user_id");
                    PreparedStatement updateStmt = conn.prepareStatement("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE user_id = ?");
                    updateStmt.setInt(1, userId);
                    updateStmt.executeUpdate();

                    User u = new User(userId, rs.getString("full_name"), rs.getString("email"), 
                                      rs.getString("phone"), hash, rs.getString("role"));

                    SessionManager.getInstance().login(u);
                    launchDashboard(u.getRole());
                    this.dispose();
                } else {
                    handleFailedAttempt(conn, rs.getInt("user_id"), rs.getInt("failed_attempts"), errorLabel);
                }
            } else {
                errorLabel.setText("Invalid credentials or role.");
            }
        } catch (Exception e) {
            errorLabel.setText("Login error occurred.");
            e.printStackTrace();
        }
    }

    private void handleFailedAttempt(Connection conn, int userId, int currentAttempts, JLabel errorLabel) throws Exception {
        currentAttempts++;
        if (currentAttempts >= 5) {
            // Lock for 15 minutes
            String lockQ = "UPDATE users SET failed_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE user_id = ?";
            PreparedStatement stmt = conn.prepareStatement(lockQ);
            stmt.setInt(1, currentAttempts);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
            errorLabel.setText("Account locked due to 5 failed attempts.");
        } else {
            String updQ = "UPDATE users SET failed_attempts = ? WHERE user_id = ?";
            PreparedStatement stmt = conn.prepareStatement(updQ);
            stmt.setInt(1, currentAttempts);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
            errorLabel.setText("Invalid credentials. Attempts left: " + (5 - currentAttempts));
        }
    }

    private void launchDashboard(String role) {
        SwingUtilities.invokeLater(() -> {
            switch (role) {
                case "ADMIN": new AdminDashboard().setVisible(true); break;
                case "TEACHER": new TeacherDashboard().setVisible(true); break;
                case "STUDENT": new StudentDashboard().setVisible(true); break;
            }
        });
    }
}

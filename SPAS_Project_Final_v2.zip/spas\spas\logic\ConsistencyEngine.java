package com.spas.logic;

import com.spas.datastructures.SemesterHistoryNode;
import com.spas.datastructures.StudentLinkedList;
import java.util.List;

public class ConsistencyEngine {
    
    public static double computeConsistency(StudentLinkedList history) {
        if (history == null || history.getSize() < 2) return 100.0; // Default max consistency for 1 sem
        
        List<SemesterHistoryNode> list = history.traverse();
        
        double sum = 0;
        for (SemesterHistoryNode n : list) {
            sum += n.getGpa();
        }
        double mean = sum / list.size();
        
        double varianceSum = 0;
        for (SemesterHistoryNode n : list) {
            varianceSum += Math.pow(n.getGpa() - mean, 2);
        }
        
        double stdDev = Math.sqrt(varianceSum / list.size());
        
        // Convert stdDev to a 0-100 score. 
        // A stdDev of 0 is perfect (100). A stdDev of 2.0+ is very bad (0).
        double score = 100 - (stdDev * 50);
        return Math.max(0, Math.min(100, score));
    }
}

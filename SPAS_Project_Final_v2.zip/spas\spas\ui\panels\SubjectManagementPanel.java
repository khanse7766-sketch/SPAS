package com.spas.ui.panels;

import com.spas.auth.SessionManager;
import com.spas.db.DBManager;
import com.spas.logic.SearchEngine;
import com.spas.models.Subject;
import com.spas.models.User;
import com.spas.validation.Validator;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubjectManagementPanel extends JPanel {
    private JTextField txtCode;
    private JTextField txtName;
    private JSpinner spCreditHours;
    private JSpinner spSemester;
    private JTextField searchField;
    private JTable table;
    private DefaultTableModel tableModel;
    private Subject[] currentSubjects = new Subject[0];
    private int selectedSubjectId = -1;

    public SubjectManagementPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Subject Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JPanel topPanel = new JPanel(new BorderLayout(0, 8));
        topPanel.add(title, BorderLayout.NORTH);
        topPanel.add(createFormPanel(), BorderLayout.CENTER);
        topPanel.add(createSearchPanel(), BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        String[] columns = {"ID", "Code", "Name", "Credit Hours", "Semester"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::handleRowSelection);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData(false);
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 5, 3, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        txtCode = new JTextField(12);
        txtName = new JTextField(18);
        spCreditHours = new JSpinner(new SpinnerNumberModel(3, 1, 6, 1));
        spSemester = new JSpinner(new SpinnerNumberModel(1, 1, 8, 1));

        addField(panel, gbc, 0, "Subject Code", txtCode);
        addField(panel, gbc, 1, "Subject Name", txtName);
        addField(panel, gbc, 2, "Credit Hours", spCreditHours);
        addField(panel, gbc, 3, "Semester", spSemester);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        JButton refreshBtn = new JButton("Refresh");
        addBtn.addActionListener(e -> addSubject());
        updateBtn.addActionListener(e -> updateSubject());
        deleteBtn.addActionListener(e -> deleteSubject());
        clearBtn.addActionListener(e -> clearForm());
        refreshBtn.addActionListener(e -> loadData(true));
        buttons.add(addBtn);
        buttons.add(updateBtn);
        buttons.add(deleteBtn);
        buttons.add(clearBtn);
        buttons.add(refreshBtn);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(buttons, gbc);
        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(15);
        JButton searchBtn = new JButton("Search");
        JButton refreshBtn = new JButton("Refresh");
        searchBtn.addActionListener(e -> performBinarySearch());
        refreshBtn.addActionListener(e -> loadData(true));
        panel.add(new JLabel("Subject Code:"));
        panel.add(searchField);
        panel.add(searchBtn);
        panel.add(refreshBtn);
        return panel;
    }

    private void addField(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent field) {
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(label + ":"), gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void loadData(boolean showMessage) {
        tableModel.setRowCount(0);
        List<Subject> subjects = new ArrayList<>();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Database connection is not available.");
            return;
        }

        String q = "SELECT subject_id, subject_code, name, credit_hours, semester FROM subjects ORDER BY subject_code";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Subject subject = new Subject(
                        rs.getInt("subject_id"),
                        rs.getString("subject_code"),
                        rs.getString("name"),
                        rs.getInt("credit_hours"),
                        rs.getInt("semester")
                );
                subjects.add(subject);
                tableModel.addRow(new Object[]{
                        subject.getSubjectId(), subject.getSubjectCode(), subject.getName(),
                        subject.getCreditHours(), subject.getSemester()
                });
            }
            currentSubjects = subjects.toArray(new Subject[0]);
            SearchEngine.sortSubjectsByCode(currentSubjects);
            if (showMessage) {
                JOptionPane.showMessageDialog(this, "Subjects loaded: " + currentSubjects.length);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage());
        }
    }

    private void addSubject() {
        if (!validateForm()) return;
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String q = "INSERT INTO subjects (subject_code, name, credit_hours, semester) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(q, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, txtCode.getText().trim().toUpperCase());
            stmt.setString(2, txtName.getText().trim());
            stmt.setInt(3, (Integer) spCreditHours.getValue());
            stmt.setInt(4, (Integer) spSemester.getValue());
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    logAction(conn, "INSERT", keys.getInt(1), "", txtCode.getText().trim().toUpperCase());
                }
            }
            JOptionPane.showMessageDialog(this, "Subject added successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not add subject: " + e.getMessage());
        }
    }

    private void updateSubject() {
        if (selectedSubjectId < 0) {
            JOptionPane.showMessageDialog(this, "Select a subject from the table first.");
            return;
        }
        if (!validateForm()) return;
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;

        String q = "UPDATE subjects SET subject_code=?, name=?, credit_hours=?, semester=? WHERE subject_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setString(1, txtCode.getText().trim().toUpperCase());
            stmt.setString(2, txtName.getText().trim());
            stmt.setInt(3, (Integer) spCreditHours.getValue());
            stmt.setInt(4, (Integer) spSemester.getValue());
            stmt.setInt(5, selectedSubjectId);
            stmt.executeUpdate();
            logAction(conn, "UPDATE", selectedSubjectId, "", txtCode.getText().trim().toUpperCase());
            JOptionPane.showMessageDialog(this, "Subject updated successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not update subject: " + e.getMessage());
        }
    }

    private void deleteSubject() {
        if (selectedSubjectId < 0) {
            JOptionPane.showMessageDialog(this, "Select a subject from the table first.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Delete selected subject?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) return;

        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try {
            logAction(conn, "DELETE", selectedSubjectId, txtCode.getText().trim(), "");
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM subjects WHERE subject_id=?")) {
                stmt.setInt(1, selectedSubjectId);
                stmt.executeUpdate();
            }
            JOptionPane.showMessageDialog(this, "Subject deleted successfully.");
            clearForm();
            loadData(false);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not delete subject: " + e.getMessage());
        }
    }

    private boolean validateForm() {
        if (txtCode.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter subject code.");
            return false;
        }
        if (txtName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter subject name.");
            return false;
        }
        if (!Validator.isValidCreditHours((Integer) spCreditHours.getValue())) {
            JOptionPane.showMessageDialog(this, "Credit hours must be between 1 and 6.");
            return false;
        }
        if (!Validator.isValidSemester((Integer) spSemester.getValue())) {
            JOptionPane.showMessageDialog(this, "Semester must be between 1 and 8.");
            return false;
        }
        return true;
    }

    private void performBinarySearch() {
        String target = searchField.getText().trim();
        if (target.isEmpty()) {
            loadData(false);
            return;
        }
        Subject found = SearchEngine.binarySearchBySubjectCode(currentSubjects, target);
        tableModel.setRowCount(0);
        if (found != null) {
            tableModel.addRow(new Object[]{
                    found.getSubjectId(), found.getSubjectCode(), found.getName(),
                    found.getCreditHours(), found.getSemester()
            });
        } else {
            JOptionPane.showMessageDialog(this, "Subject not found.");
            loadData(false);
        }
    }

    private void handleRowSelection(ListSelectionEvent event) {
        if (event.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
        int row = table.convertRowIndexToModel(table.getSelectedRow());
        selectedSubjectId = (Integer) tableModel.getValueAt(row, 0);
        txtCode.setText(value(row, 1));
        txtName.setText(value(row, 2));
        spCreditHours.setValue((Integer) tableModel.getValueAt(row, 3));
        spSemester.setValue((Integer) tableModel.getValueAt(row, 4));
    }

    private String value(int row, int col) {
        Object value = tableModel.getValueAt(row, col);
        return value == null ? "" : value.toString();
    }

    private void clearForm() {
        selectedSubjectId = -1;
        txtCode.setText("");
        txtName.setText("");
        spCreditHours.setValue(3);
        spSemester.setValue(1);
        table.clearSelection();
    }

    private void logAction(Connection conn, String actionType, int recordId, String oldValue, String newValue) throws SQLException {
        User user = SessionManager.getInstance().getCurrentUser();
        String q = "INSERT INTO action_log (action_type, table_name, record_id, old_value, new_value, performed_by) VALUES (?, 'subjects', ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setString(1, actionType);
            stmt.setInt(2, recordId);
            stmt.setString(3, oldValue);
            stmt.setString(4, newValue);
            if (user == null) {
                stmt.setNull(5, Types.INTEGER);
            } else {
                stmt.setInt(5, user.getUserId());
            }
            stmt.executeUpdate();
        }
    }
}

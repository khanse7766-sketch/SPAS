package com.spas.logic;

import com.spas.models.Student;
import com.spas.models.Subject;

public class SearchEngine {

    /**
     * Performs a manual Binary Search on an array of Students by Roll Number.
     * To satisfy the CS-201 requirement for O(log n) lookup.
     * Assumes the array is ALREADY sorted by roll number.
     */
    public static Student binarySearchByRollNo(Student[] arr, String targetRollNo) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int res = targetRollNo.compareToIgnoreCase(arr[mid].getRollNo());

            if (res == 0) {
                return arr[mid];
            }
            if (res > 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    /**
     * Helper to sort students by Roll No before searching.
     * Uses manual Bubble Sort or Insertion Sort to keep it simple, or we can reuse QuickSort.
     */
    public static void sortStudentsByRollNo(Student[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j].getRollNo().compareToIgnoreCase(arr[j + 1].getRollNo()) > 0) {
                    Student temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static Subject binarySearchBySubjectCode(Subject[] arr, String targetCode) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = targetCode.compareToIgnoreCase(arr[mid].getSubjectCode());

            if (result == 0) {
                return arr[mid];
            }
            if (result > 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void sortSubjectsByCode(Subject[] arr) {
        for (int i = 1; i < arr.length; i++) {
            Subject current = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j].getSubjectCode().compareToIgnoreCase(current.getSubjectCode()) > 0) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }
}

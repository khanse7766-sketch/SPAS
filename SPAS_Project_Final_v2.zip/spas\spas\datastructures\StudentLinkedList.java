package com.spas.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom Singly Linked List implementation to satisfy CS-201 project requirements.
 * Used for maintaining the academic/semester history of a student.
 */
public class StudentLinkedList {
    private SemesterHistoryNode head;
    private int size;

    public StudentLinkedList() {
        this.head = null;
        this.size = 0;
    }

    /**
     * Inserts a new semester record at the head of the list so the most recent is first.
     */
    public void insertAtHead(int semester, double gpa, double cgpa, int classRank, double consistencyScore, double amiScore) {
        SemesterHistoryNode newNode = new SemesterHistoryNode(semester, gpa, cgpa, classRank, consistencyScore, amiScore);
        newNode.setNext(head);
        head = newNode;
        size++;
    }

    /**
     * Traverses the list and returns it as a Java List for easier UI integration,
     * maintaining the order (most recent first).
     */
    public List<SemesterHistoryNode> traverse() {
        List<SemesterHistoryNode> list = new ArrayList<>();
        SemesterHistoryNode current = head;
        while (current != null) {
            list.add(current);
            current = current.getNext();
        }
        return list;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public int getSize() {
        return size;
    }
    
    public SemesterHistoryNode getHead() {
        return head;
    }
}

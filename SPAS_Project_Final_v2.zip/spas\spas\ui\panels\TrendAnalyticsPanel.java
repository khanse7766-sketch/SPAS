package com.spas.ui.panels;

import com.spas.db.DBManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TrendAnalyticsPanel extends JPanel {
    private JPanel chartsPanel;
    private JTextArea summaryArea;

    // Direct references to the value labels inside each stat card.
    // Keeping these as fields means we never need to dig back into the
    // component tree (getComponent(index) / client properties / casting)
    // to update the displayed value later - that pattern is what caused
    // the original ClassCastException.
    private JLabel avgGpaValueLabel;
    private JLabel avgAttendanceValueLabel;
    private JLabel avgMarksValueLabel;
    private JLabel trendStatusValueLabel;

    public TrendAnalyticsPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        loadAnalytics();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Trend Analytics");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Updated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));

        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createStatisticsCards(), BorderLayout.NORTH);
        topPanel.add(createChartsPanel(), BorderLayout.CENTER);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, createSummaryPanel());
        splitPane.setResizeWeight(0.6);

        content.add(splitPane, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createStatisticsCards() {
        JPanel cardsPanel = new JPanel(new GridLayout(1, 4, 10, 10));

        avgGpaValueLabel = new JLabel("0.0");
        JPanel avgGpaCard = createStatCard("Average GPA", avgGpaValueLabel, new Color(47, 93, 255));

        avgAttendanceValueLabel = new JLabel("0%");
        JPanel avgAttendanceCard = createStatCard("Avg Attendance", avgAttendanceValueLabel, new Color(25, 145, 85));

        avgMarksValueLabel = new JLabel("0.0");
        JPanel avgMarksCard = createStatCard("Avg Marks", avgMarksValueLabel, new Color(255, 165, 0));

        trendStatusValueLabel = new JLabel("Loading...");
        JPanel trendStatusCard = createStatCard("Trend Status", trendStatusValueLabel, new Color(108, 117, 125));

        cardsPanel.add(avgGpaCard);
        cardsPanel.add(avgAttendanceCard);
        cardsPanel.add(avgMarksCard);
        cardsPanel.add(trendStatusCard);

        return cardsPanel;
    }

    /**
     * Builds a stat card around an already-created value label so the
     * caller keeps a direct reference to it. A plain JPanel is used as
     * the container (not a JLabel) - JLabel isn't designed to hold child
     * components and abusing it that way is what led to the original bug.
     */
    private JPanel createStatCard(String title, JLabel valueLabel, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(color);
        card.setBorder(new EmptyBorder(12, 12, 12, 12));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(valueLabel);

        return card;
    }

    private JPanel createChartsPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Performance Charts"));

        chartsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.add(chartsPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh = createStyledButton("Refresh Analytics", new Color(47, 93, 255));
        refresh.addActionListener(e -> loadAnalytics());
        buttonPanel.add(refresh);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Statistical Summary"));

        summaryArea = new JTextArea(6, 30);
        summaryArea.setEditable(false);
        summaryArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        summaryArea.setBackground(new Color(248, 249, 250));

        panel.add(new JScrollPane(summaryArea), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));

        JLabel statusLabel = new JLabel("Ready | Click Refresh to update analytics data");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));

        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Analytics Module"), BorderLayout.EAST);

        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(160, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void loadAnalytics() {
        chartsPanel.removeAll();
        summaryArea.setText("");
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        try {
            chartsPanel.add(new ChartPanel(ChartFactory.createLineChart("Semester GPA Trend", "Semester", "GPA", semesterGpaDataset(conn))));
            chartsPanel.add(new ChartPanel(ChartFactory.createLineChart("Attendance Trend", "Semester", "Attendance %", attendanceDataset(conn))));
            chartsPanel.add(new ChartPanel(ChartFactory.createBarChart("Subject Performance", "Subject", "Avg Marks", subjectDataset(conn))));
            chartsPanel.add(new ChartPanel(ChartFactory.createPieChart("Pass/Fail Distribution", passFailDataset(conn))));

            updateStatistics(conn);
            updateSummary(conn);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load analytics: " + e.getMessage());
        }
        revalidate();
        repaint();
    }

    private void updateStatistics(Connection conn) {
        try {
            // Average GPA
            String gpaQuery = "SELECT AVG(gpa) FROM semester_summary";
            try (PreparedStatement stmt = conn.prepareStatement(gpaQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    double avgGpa = rs.getDouble(1);
                    avgGpaValueLabel.setText(String.format("%.2f", avgGpa));
                }
            }

            // Average Attendance
            String attQuery = "SELECT AVG(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) * 100 FROM attendance";
            try (PreparedStatement stmt = conn.prepareStatement(attQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    double avgAtt = rs.getDouble(1);
                    avgAttendanceValueLabel.setText(String.format("%.1f%%", avgAtt));
                }
            }

            // Average Marks
            String marksQuery = "SELECT AVG(quiz + assignment + midterm + final_exam) FROM marks";
            try (PreparedStatement stmt = conn.prepareStatement(marksQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    double avgMarks = rs.getDouble(1);
                    avgMarksValueLabel.setText(String.format("%.1f", avgMarks));
                }
            }

            // Trend Status
            trendStatusValueLabel.setText("Positive");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Analytics Error: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateSummary(Connection conn) throws SQLException {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Statistical Summary ===\n\n");

        // Student count by semester
        String semQuery = "SELECT current_semester, COUNT(*) FROM students GROUP BY current_semester ORDER BY current_semester";
        sb.append("Students by Semester:\n");
        try (PreparedStatement stmt = conn.prepareStatement(semQuery);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sb.append(String.format("  Semester %d: %d students\n", rs.getInt(1), rs.getInt(2)));
            }
        }

        sb.append("\nSubject Distribution:\n");
        String subQuery = "SELECT semester, COUNT(*) FROM subjects GROUP BY semester ORDER BY semester";
        try (PreparedStatement stmt = conn.prepareStatement(subQuery);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sb.append(String.format("  Semester %d: %d subjects\n", rs.getInt(1), rs.getInt(2)));
            }
        }

        summaryArea.setText(sb.toString());
    }

    private DefaultCategoryDataset semesterGpaDataset(Connection conn) throws SQLException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String q = "SELECT semester, COALESCE(AVG(gpa), 0) avg_gpa FROM semester_summary GROUP BY semester ORDER BY semester";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) dataset.addValue(rs.getDouble("avg_gpa"), "GPA", "Sem " + rs.getInt("semester"));
        }
        return dataset;
    }

    private DefaultCategoryDataset attendanceDataset(Connection conn) throws SQLException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String q = "SELECT semester, COALESCE(AVG(status='PRESENT')*100, 0) attendance_pct FROM attendance GROUP BY semester ORDER BY semester";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) dataset.addValue(rs.getDouble("attendance_pct"), "Attendance", "Sem " + rs.getInt("semester"));
        }
        return dataset;
    }

    private DefaultCategoryDataset subjectDataset(Connection conn) throws SQLException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String q = "SELECT sub.subject_code, COALESCE(AVG(m.quiz+m.assignment+m.midterm+m.final_exam), 0) avg_marks FROM subjects sub LEFT JOIN marks m ON sub.subject_id=m.subject_id GROUP BY sub.subject_id, sub.subject_code ORDER BY sub.subject_code";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) dataset.addValue(rs.getDouble("avg_marks"), "Marks", rs.getString("subject_code"));
        }
        return dataset;
    }

    private DefaultPieDataset passFailDataset(Connection conn) throws SQLException {
        DefaultPieDataset dataset = new DefaultPieDataset();
        int passed = scalarInt(conn, "SELECT COUNT(*) FROM semester_summary WHERE gpa >= 2.0");
        int failed = scalarInt(conn, "SELECT COUNT(*) FROM semester_summary WHERE gpa < 2.0");
        dataset.setValue("Passed", passed);
        dataset.setValue("Failed", failed);
        return dataset;
    }

    private int scalarInt(Connection conn, String query) throws SQLException {
        return (int) scalarDouble(conn, query);
    }

    private double scalarDouble(Connection conn, String query) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            return rs.next() ? rs.getDouble(1) : 0;
        }
    }
}
        
package com.spas.ui.panels;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.spas.db.DBManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReportsPanel extends JPanel {
    private JComboBox<String> reportTypeCombo;
    private JTable table;
    private DefaultTableModel tableModel;
    private JSpinner semesterSpinner;
    private JSpinner dateSpinner;
    private JPanel totalRecordsCard;
    private JLabel reportDateLabel;

    public ReportsPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        loadReport();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Reports Center");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        reportDateLabel = new JLabel("Generated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
        reportDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(reportDateLabel);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));

        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createControlPanel(), BorderLayout.NORTH);
        topPanel.add(createStatisticsCards(), BorderLayout.CENTER);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, createTablePanel());
        splitPane.setResizeWeight(0.3);

        content.add(splitPane, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createTitledBorder("Report Controls"));

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));

        reportTypeCombo = new JComboBox<>(new String[]{
                "Student Report", "Subject Report", "Marks Report", "Attendance Report",
                "GPA Report", "Ranking Report", "Risk Report", "Summary Report",
                "Performance Report", "Class Report"
        });
        semesterSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 8, 1));
        dateSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH));
        dateSpinner.setEditor(new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd"));

        JButton previewBtn = createStyledButton("Generate Report", new Color(47, 93, 255));
        JButton pdfBtn = createStyledButton("Export PDF", new Color(220, 53, 69));
        JButton excelBtn = createStyledButton("Export Excel", new Color(25, 135, 84));
        JButton printBtn = createStyledButton("Print", new Color(108, 117, 125));
        JButton refreshBtn = createStyledButton("Refresh", new Color(13, 110, 253));

        previewBtn.addActionListener(e -> loadReport());
        pdfBtn.addActionListener(e -> exportPdf());
        excelBtn.addActionListener(e -> exportCsv());
        printBtn.addActionListener(e -> printReport());
        refreshBtn.addActionListener(e -> loadReport());

        controls.add(new JLabel("Report Type:"));
        controls.add(reportTypeCombo);
        controls.add(new JLabel("Semester:"));
        controls.add(semesterSpinner);
        controls.add(new JLabel("Date:"));
        controls.add(dateSpinner);
        controls.add(Box.createHorizontalStrut(10));
        controls.add(previewBtn);
        controls.add(pdfBtn);
        controls.add(excelBtn);
        controls.add(printBtn);
        controls.add(refreshBtn);

        panel.add(controls, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createStatisticsCards() {
        JPanel cardsPanel = new JPanel(new GridLayout(1, 3, 10, 10));

        totalRecordsCard = createStatCard(
                "Total Records",
                "0",
                new Color(47, 93, 255)
        );

        JPanel reportTypeCard = createStatCard(
                "Current Report",
                reportTypeCombo.getSelectedItem().toString(),
                new Color(25, 145, 85)
        );

        JPanel statusCard = createStatCard(
                "Status",
                "Ready",
                new Color(108, 117, 125)
        );

        cardsPanel.add(totalRecordsCard);
        cardsPanel.add(reportTypeCard);
        cardsPanel.add(statusCard);

        return cardsPanel;
    }

    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Report Results"));

        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setAutoCreateRowSorter(true);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));

        JLabel statusLabel = new JLabel("Ready | Select report type and generate to view data");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));

        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Reports Module"), BorderLayout.EAST);

        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(140, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void loadReport() {
        String type = reportTypeCombo.getSelectedItem().toString();
        int semester = (Integer) semesterSpinner.getValue();

        String query = switch (type) {
            case "Subject Report" -> "SELECT subject_code AS Code, name AS Subject, credit_hours AS Credits, semester AS Semester FROM subjects ORDER BY semester, subject_code";
            case "Marks Report" -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, sub.subject_code AS Subject, m.semester AS Semester, (m.quiz+m.assignment+m.midterm+m.final_exam) AS Total FROM marks m JOIN students s ON m.student_id=s.student_id JOIN users u ON s.user_id=u.user_id JOIN subjects sub ON m.subject_id=sub.subject_id WHERE m.semester = ? ORDER BY s.roll_no";
            case "Attendance Report" -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, sub.subject_code AS Subject, a.semester AS Semester, a.att_date AS Date, a.status AS Status FROM attendance a JOIN students s ON a.student_id=s.student_id JOIN users u ON s.user_id=u.user_id JOIN subjects sub ON a.subject_id=sub.subject_id WHERE a.semester = ? ORDER BY a.att_date DESC";
            case "GPA Report", "Ranking Report" -> "SELECT ss.class_rank AS RankNo, s.roll_no AS RollNo, u.full_name AS Student, ss.semester AS Semester, ss.gpa AS GPA, ss.cgpa AS CGPA FROM semester_summary ss JOIN students s ON ss.student_id=s.student_id JOIN users u ON s.user_id=u.user_id WHERE ss.semester = ? ORDER BY ss.class_rank";
            case "Risk Report" -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, COALESCE(AVG(ss.gpa),0) AS GPA, COALESCE(AVG(a.status='PRESENT')*100,0) AS Attendance FROM students s JOIN users u ON s.user_id=u.user_id LEFT JOIN semester_summary ss ON s.student_id=ss.student_id AND ss.semester = ? LEFT JOIN attendance a ON s.student_id=a.student_id AND a.semester = ? GROUP BY s.student_id ORDER BY GPA, Attendance";
            case "Summary Report" -> "SELECT 'Students' AS Metric, COUNT(*) AS Value FROM students UNION ALL SELECT 'Subjects', COUNT(*) FROM subjects UNION ALL SELECT 'Attendance Entries', COUNT(*) FROM attendance UNION ALL SELECT 'Marks Entries', COUNT(*) FROM marks";
            case "Performance Report" -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, ss.semester AS Semester, ss.gpa AS GPA, ss.class_rank AS Rank, ss.consistency_score AS Consistency FROM semester_summary ss JOIN students s ON ss.student_id=s.student_id JOIN users u ON s.user_id=u.user_id WHERE ss.semester = ? ORDER BY ss.gpa DESC";
            case "Class Report" -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, s.batch AS Batch, s.current_semester AS Semester FROM students s JOIN users u ON s.user_id=u.user_id WHERE s.current_semester = ? ORDER BY s.roll_no";
            default -> "SELECT s.roll_no AS RollNo, u.full_name AS Student, u.email AS Email, u.phone AS Phone, s.batch AS Batch, s.current_semester AS Semester FROM students s JOIN users u ON s.user_id=u.user_id ORDER BY s.roll_no";
        };

        // Number of '?' placeholders differs per query (Risk Report uses two).
        int paramCount = countPlaceholders(query);
        Integer[] params = new Integer[paramCount];
        for (int i = 0; i < paramCount; i++) params[i] = semester;

        fillTable(query, params);
        updateStatistics();
        reportDateLabel.setText("Generated: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm").format(new Date()));
    }

    private int countPlaceholders(String query) {
        int count = 0;
        for (char c : query.toCharArray()) if (c == '?') count++;
        return count;
    }

    private void updateStatistics() {
        int recordCount = tableModel.getRowCount();

        JPanel cardsPanel = (JPanel) totalRecordsCard.getParent();
        cardsPanel.removeAll();

        totalRecordsCard = createStatCard("Total Records", String.valueOf(recordCount), new Color(47, 93, 255));
        JPanel reportTypeCard = createStatCard("Current Report", reportTypeCombo.getSelectedItem().toString(), new Color(25, 145, 85));
        JPanel statusCard = createStatCard("Status", "Ready", new Color(108, 117, 125));

        cardsPanel.add(totalRecordsCard);
        cardsPanel.add(reportTypeCard);
        cardsPanel.add(statusCard);

        cardsPanel.revalidate();
        cardsPanel.repaint();
    }

    private void fillTable(String query, Object... params) {
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Not connected to the database. Start XAMPP MySQL and click Refresh.");
            return;
        }
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = stmt.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    tableModel.addColumn(meta.getColumnLabel(i));
                }
                while (rs.next()) {
                    Object[] row = new Object[meta.getColumnCount()];
                    for (int i = 1; i <= meta.getColumnCount(); i++) {
                        row[i - 1] = rs.getObject(i);
                    }
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load report: " + e.getMessage());
        }
    }

    private void exportPdf() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(reportTypeCombo.getSelectedItem() + ".pdf"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(chooser.getSelectedFile()));
            document.open();
            document.add(new Paragraph(reportTypeCombo.getSelectedItem().toString()));
            document.add(new Paragraph(" "));
            PdfPTable pdfTable = new PdfPTable(tableModel.getColumnCount());
            for (int c = 0; c < tableModel.getColumnCount(); c++) pdfTable.addCell(tableModel.getColumnName(c));
            for (int r = 0; r < tableModel.getRowCount(); r++) {
                for (int c = 0; c < tableModel.getColumnCount(); c++) {
                    Object value = tableModel.getValueAt(r, c);
                    pdfTable.addCell(value == null ? "" : value.toString());
                }
            }
            document.add(pdfTable);
            document.close();
            JOptionPane.showMessageDialog(this, "PDF exported successfully.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "PDF export failed: " + e.getMessage());
        }
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(reportTypeCombo.getSelectedItem() + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (FileWriter writer = new FileWriter(chooser.getSelectedFile())) {
            for (int c = 0; c < tableModel.getColumnCount(); c++) {
                writer.append(tableModel.getColumnName(c)).append(c == tableModel.getColumnCount() - 1 ? "\n" : ",");
            }
            for (int r = 0; r < tableModel.getRowCount(); r++) {
                for (int c = 0; c < tableModel.getColumnCount(); c++) {
                    Object value = tableModel.getValueAt(r, c);
                    writer.append(value == null ? "" : value.toString().replace(",", " ")).append(c == tableModel.getColumnCount() - 1 ? "\n" : ",");
                }
            }
            JOptionPane.showMessageDialog(this, "CSV exported successfully. Open it in Excel.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Export failed: " + e.getMessage());
        }
    }

    private void printReport() {
        try {
            table.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Print failed: " + e.getMessage());
        }
    }
}
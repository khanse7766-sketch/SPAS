package com.spas.models;

import java.sql.Date;

public class Attendance {
    private int attId;
    private int studentId;
    private int subjectId;
    private int semester;
    private Date attDate;
    private String status;

    public Attendance(int attId, int studentId, int subjectId, int semester, Date attDate, String status) {
        this.attId = attId;
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.semester = semester;
        this.attDate = attDate;
        this.status = status;
    }

    public int getAttId() { return attId; }
    public int getStudentId() { return studentId; }
    public int getSubjectId() { return subjectId; }
    public int getSemester() { return semester; }
    public Date getAttDate() { return attDate; }
    public String getStatus() { return status; }
}

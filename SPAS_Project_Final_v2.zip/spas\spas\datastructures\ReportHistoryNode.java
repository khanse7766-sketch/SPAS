package com.spas.datastructures;

import java.sql.Timestamp;

public class ReportHistoryNode {
    private String reportType;
    private String reportOutput;
    private Timestamp generatedAt;
    private ReportHistoryNode next;

    public ReportHistoryNode(String reportType, String reportOutput, Timestamp generatedAt) {
        this.reportType = reportType;
        this.reportOutput = reportOutput;
        this.generatedAt = generatedAt;
        this.next = null;
    }

    public String getReportType() { return reportType; }
    public String getReportOutput() { return reportOutput; }
    public Timestamp getGeneratedAt() { return generatedAt; }
    public ReportHistoryNode getNext() { return next; }
    public void setNext(ReportHistoryNode next) { this.next = next; }
}

package com.spas.ui.panels;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.spas.auth.SessionManager;
import com.spas.db.DBManager;
import com.spas.models.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AttendanceManagementPanel extends JPanel {
    private JComboBox<String> semesterCombo;
    private JComboBox<String> subjectCombo;
    private JComboBox<String> sectionCombo;
    private JSpinner dateSpinner;
    private JTable attendanceTable;
    private DefaultTableModel attendanceTableModel;
    private JTable historyTable;
    private DefaultTableModel historyTableModel;
    private Map<Integer, String> studentAttendanceMap;
    private JLabel totalPresentLabel;
    private JLabel totalAbsentLabel;
    private JLabel totalLateLabel;
    private JLabel totalLeaveLabel;
    private JLabel totalMedicalLabel;
    private JLabel attendancePercentageLabel;
    private JComboBox<String> reportTypeCombo;
    private JSpinner reportDateSpinner;

    public AttendanceManagementPanel() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(12, 12, 12, 12));
        studentAttendanceMap = new HashMap<>();

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        loadSemesters();
        loadSubjects();
        loadSections();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        JLabel title = new JLabel("Attendance Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        
        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        JLabel dateLabel = new JLabel("Date: " + new SimpleDateFormat("EEE, dd MMM yyyy").format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rightPanel.add(dateLabel);
        
        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent createMainContent() {
        JPanel content = new JPanel(new BorderLayout(12, 12));
        
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.add(createControlPanel(), BorderLayout.NORTH);
        topPanel.add(createStatisticsCards(), BorderLayout.CENTER);
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, createTablesPanel());
        splitPane.setResizeWeight(0.4);
        
        content.add(splitPane, BorderLayout.CENTER);
        return new JScrollPane(content);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(BorderFactory.createTitledBorder("Attendance Controls"));
        
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        
        semesterCombo = new JComboBox<>();
        subjectCombo = new JComboBox<>();
        sectionCombo = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        dateSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH));
        dateSpinner.setEditor(new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd"));
        
        JButton loadBtn = createStyledButton("Load Students", new Color(47, 93, 255));
        JButton saveBtn = createStyledButton("Save Attendance", new Color(25, 145, 85));
        JButton updateBtn = createStyledButton("Update Attendance", new Color(255, 165, 0));
        JButton deleteBtn = createStyledButton("Delete Attendance", new Color(220, 53, 69));
        JButton resetBtn = createStyledButton("Reset", new Color(108, 117, 125));
        JButton refreshBtn = createStyledButton("Refresh", new Color(13, 110, 253));
        
        loadBtn.addActionListener(e -> loadStudentsForAttendance());
        saveBtn.addActionListener(e -> saveBatchAttendance());
        updateBtn.addActionListener(e -> updateBatchAttendance());
        deleteBtn.addActionListener(e -> deleteAttendance());
        resetBtn.addActionListener(e -> resetAttendanceForm());
        refreshBtn.addActionListener(e -> loadAttendanceHistory());
        
        controls.add(new JLabel("Semester:"));
        controls.add(semesterCombo);
        controls.add(new JLabel("Subject:"));
        controls.add(subjectCombo);
        controls.add(new JLabel("Section:"));
        controls.add(sectionCombo);
        controls.add(new JLabel("Date:"));
        controls.add(dateSpinner);
        controls.add(Box.createHorizontalStrut(10));
        controls.add(loadBtn);
        controls.add(saveBtn);
        controls.add(updateBtn);
        controls.add(deleteBtn);
        controls.add(resetBtn);
        controls.add(refreshBtn);
        
        panel.add(controls, BorderLayout.CENTER);
        
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchField = new JTextField(15);
        JButton searchBtn = createStyledButton("Search Student", new Color(13, 202, 240));
        searchBtn.addActionListener(e -> searchStudent(searchField.getText().trim()));
        searchPanel.add(new JLabel("Search by Roll No:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        
        panel.add(searchPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private JPanel createStatisticsCards() {
        JPanel cardsPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        
        totalPresentLabel = createStatCard("Total Present", "0", new Color(25, 145, 85));
        totalAbsentLabel = createStatCard("Total Absent", "0", new Color(220, 53, 69));
        totalLateLabel = createStatCard("Total Late", "0", new Color(255, 165, 0));
        totalLeaveLabel = createStatCard("Total Leave", "0", new Color(13, 110, 253));
        totalMedicalLabel = createStatCard("Medical Leave", "0", new Color(108, 117, 125));
        attendancePercentageLabel = createStatCard("Attendance %", "0%", new Color(47, 93, 255));
        
        cardsPanel.add(totalPresentLabel);
        cardsPanel.add(totalAbsentLabel);
        cardsPanel.add(totalLateLabel);
        cardsPanel.add(totalLeaveLabel);
        cardsPanel.add(totalMedicalLabel);
        cardsPanel.add(attendancePercentageLabel);
        
        return cardsPanel;
    }

    private JLabel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setBackground(color);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        JLabel wrapper = new JLabel();
        wrapper.setLayout(new BorderLayout());
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createTablesPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        
        // Attendance Entry Table
        JPanel attendancePanel = new JPanel(new BorderLayout(8, 8));
        attendancePanel.setBorder(BorderFactory.createTitledBorder("Mark Attendance"));
        
        String[] attendanceColumns = {"Student ID", "Roll No", "Student Name", "Department", "Status"};
        attendanceTableModel = new DefaultTableModel(attendanceColumns, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 4) return String.class;
                return super.getColumnClass(column);
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        
        attendanceTable = new JTable(attendanceTableModel);
        attendanceTable.setRowHeight(30);
        
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"PRESENT", "ABSENT", "LATE", "LEAVE", "MEDICAL_LEAVE"});
        attendanceTable.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(statusCombo));
        
        attendancePanel.add(new JScrollPane(attendanceTable), BorderLayout.CENTER);
        
        // Attendance History Table
        JPanel historyPanel = new JPanel(new BorderLayout(8, 8));
        historyPanel.setBorder(BorderFactory.createTitledBorder("Attendance History"));
        
        String[] historyColumns = {"ID", "Roll No", "Student", "Subject", "Semester", "Date", "Status"};
        historyTableModel = new DefaultTableModel(historyColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        historyTable = new JTable(historyTableModel);
        historyTable.setRowHeight(25);
        historyTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column == 6 && !isSelected) {
                    String status = value.toString();
                    if ("PRESENT".equals(status)) {
                        c.setForeground(new Color(25, 145, 85));
                    } else if ("ABSENT".equals(status)) {
                        c.setForeground(new Color(220, 53, 69));
                    } else if ("LATE".equals(status)) {
                        c.setForeground(new Color(255, 165, 0));
                    } else if ("LEAVE".equals(status)) {
                        c.setForeground(new Color(13, 110, 253));
                    } else if ("MEDICAL_LEAVE".equals(status)) {
                        c.setForeground(new Color(108, 117, 125));
                    }
                }
                return c;
            }
        });
        
        historyPanel.add(new JScrollPane(historyTable), BorderLayout.CENTER);
        
        // Report Controls
        JPanel reportPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        reportTypeCombo = new JComboBox<>(new String[]{
            "Daily Report", "Weekly Report", "Monthly Report", "Semester Report", 
            "Subject Report", "Student Report"
        });
        reportDateSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH));
        reportDateSpinner.setEditor(new JSpinner.DateEditor(reportDateSpinner, "yyyy-MM-dd"));
        
        JButton generateReportBtn = createStyledButton("Generate Report", new Color(47, 93, 255));
        JButton exportPdfBtn = createStyledButton("Export PDF", new Color(220, 53, 69));
        JButton exportExcelBtn = createStyledButton("Export Excel", new Color(25, 135, 84));
        JButton printBtn = createStyledButton("Print", new Color(108, 117, 125));
        
        generateReportBtn.addActionListener(e -> generateReport());
        exportPdfBtn.addActionListener(e -> exportToPdf());
        exportExcelBtn.addActionListener(e -> exportToExcel());
        printBtn.addActionListener(e -> printReport());
        
        reportPanel.add(new JLabel("Report Type:"));
        reportPanel.add(reportTypeCombo);
        reportPanel.add(new JLabel("Date:"));
        reportPanel.add(reportDateSpinner);
        reportPanel.add(generateReportBtn);
        reportPanel.add(exportPdfBtn);
        reportPanel.add(exportExcelBtn);
        reportPanel.add(printBtn);
        
        historyPanel.add(reportPanel, BorderLayout.SOUTH);
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, attendancePanel, historyPanel);
        splitPane.setResizeWeight(0.5);
        
        panel.add(splitPane, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(8, 8, 8, 8));
        footer.setBackground(new Color(245, 247, 252));
        
        JLabel statusLabel = new JLabel("Ready | Select semester, subject, and date to load students");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        
        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(new JLabel("SPAS v1.0 - Attendance Module"), BorderLayout.EAST);
        
        return footer;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(140, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void loadSemesters() {
        semesterCombo.removeAllItems();
        for (int i = 1; i <= 8; i++) {
            semesterCombo.addItem("Semester " + i);
        }
        if (semesterCombo.getItemCount() > 0) {
            semesterCombo.setSelectedIndex(0);
        }
    }

    private void loadSubjects() {
        subjectCombo.removeAllItems();
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        String q = "SELECT subject_id, subject_code, name, semester FROM subjects ORDER BY semester, subject_code";
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                subjectCombo.addItem(rs.getInt("subject_id") + " - " + rs.getString("subject_code") + 
                                    " - " + rs.getString("name") + " (Sem " + rs.getInt("semester") + ")");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load subjects: " + e.getMessage());
        }
    }

    private void loadSections() {
        // Sections are already set in constructor
    }

    private void loadStudentsForAttendance() {
        if (semesterCombo.getSelectedItem() == null || subjectCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select semester and subject.");
            return;
        }
        
        attendanceTableModel.setRowCount(0);
        studentAttendanceMap.clear();
        
        int semester = semesterCombo.getSelectedIndex() + 1;
        int subjectId = Integer.parseInt(subjectCombo.getSelectedItem().toString().split(" - ")[0]);
        String section = sectionCombo.getSelectedItem().toString();
        Date date = (Date) dateSpinner.getValue();
        
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        String q = "SELECT s.student_id, s.roll_no, u.full_name, s.batch " +
                   "FROM students s JOIN users u ON s.user_id = u.user_id " +
                   "WHERE s.current_semester = ? ORDER BY s.roll_no";
        
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setInt(1, semester);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int studentId = rs.getInt("student_id");
                attendanceTableModel.addRow(new Object[]{
                    studentId,
                    rs.getString("roll_no"),
                    rs.getString("full_name"),
                    rs.getString("batch"),
                    "PRESENT"
                });
                studentAttendanceMap.put(studentId, "PRESENT");
            }
            
            // Load existing attendance for this date
            loadExistingAttendance(conn, subjectId, semester, date);
            
            updateStatistics();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load students: " + e.getMessage());
        }
    }

    private void loadExistingAttendance(Connection conn, int subjectId, int semester, Date date) throws SQLException {
        String q = "SELECT student_id, status FROM attendance WHERE subject_id = ? AND semester = ? AND att_date = ?";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setInt(1, subjectId);
            stmt.setInt(2, semester);
            stmt.setDate(3, new java.sql.Date(date.getTime()));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int studentId = rs.getInt("student_id");
                String status = rs.getString("status");
                studentAttendanceMap.put(studentId, status);
                
                // Update table
                for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
                    if ((Integer) attendanceTableModel.getValueAt(i, 0) == studentId) {
                        attendanceTableModel.setValueAt(status, i, 4);
                        break;
                    }
                }
            }
        }
    }

    private void saveBatchAttendance() {
        if (attendanceTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No students loaded. Please load students first.");
            return;
        }
        
        if (subjectCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a subject.");
            return;
        }
        
        int semester = semesterCombo.getSelectedIndex() + 1;
        int subjectId = Integer.parseInt(subjectCombo.getSelectedItem().toString().split(" - ")[0]);
        Date date = (Date) dateSpinner.getValue();
        
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        try {
            conn.setAutoCommit(false);
            
            int savedCount = 0;
            int duplicateCount = 0;
            
            for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
                int studentId = (Integer) attendanceTableModel.getValueAt(i, 0);
                String status = attendanceTableModel.getValueAt(i, 4).toString();
                
                // Check if attendance already exists
                String checkQ = "SELECT att_id FROM attendance WHERE student_id = ? AND subject_id = ? AND semester = ? AND att_date = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkQ)) {
                    checkStmt.setInt(1, studentId);
                    checkStmt.setInt(2, subjectId);
                    checkStmt.setInt(3, semester);
                    checkStmt.setDate(4, new java.sql.Date(date.getTime()));
                    ResultSet checkRs = checkStmt.executeQuery();
                    
                    if (checkRs.next()) {
                        duplicateCount++;
                        continue;
                    }
                }
                
                // Insert new attendance
                String insertQ = "INSERT INTO attendance (student_id, subject_id, semester, att_date, status) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertQ, Statement.RETURN_GENERATED_KEYS)) {
                    insertStmt.setInt(1, studentId);
                    insertStmt.setInt(2, subjectId);
                    insertStmt.setInt(3, semester);
                    insertStmt.setDate(4, new java.sql.Date(date.getTime()));
                    insertStmt.setString(5, status);
                    insertStmt.executeUpdate();
                    
                    try (ResultSet keys = insertStmt.getGeneratedKeys()) {
                        if (keys.next()) {
                            logAction(conn, "INSERT", keys.getInt(1), "", status);
                        }
                    }
                    savedCount++;
                }
            }
            
            conn.commit();
            
            String message = "Attendance saved successfully.\n";
            message += "New records: " + savedCount + "\n";
            if (duplicateCount > 0) {
                message += "Skipped duplicates: " + duplicateCount;
            }
            JOptionPane.showMessageDialog(this, message);
            
            loadAttendanceHistory();
            updateStatistics();
            
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                // Ignore rollback error
            }
            JOptionPane.showMessageDialog(this, "Could not save attendance: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                // Ignore
            }
        }
    }

    private void updateBatchAttendance() {
        if (attendanceTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No students loaded. Please load students first.");
            return;
        }
        
        if (subjectCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a subject.");
            return;
        }
        
        int semester = semesterCombo.getSelectedIndex() + 1;
        int subjectId = Integer.parseInt(subjectCombo.getSelectedItem().toString().split(" - ")[0]);
        Date date = (Date) dateSpinner.getValue();
        
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        try {
            conn.setAutoCommit(false);
            
            int updatedCount = 0;
            
            for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
                int studentId = (Integer) attendanceTableModel.getValueAt(i, 0);
                String status = attendanceTableModel.getValueAt(i, 4).toString();
                
                // Check if attendance exists
                String checkQ = "SELECT att_id FROM attendance WHERE student_id = ? AND subject_id = ? AND semester = ? AND att_date = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkQ)) {
                    checkStmt.setInt(1, studentId);
                    checkStmt.setInt(2, subjectId);
                    checkStmt.setInt(3, semester);
                    checkStmt.setDate(4, new java.sql.Date(date.getTime()));
                    ResultSet checkRs = checkStmt.executeQuery();
                    
                    if (checkRs.next()) {
                        int attId = checkRs.getInt("att_id");
                        
                        // Update existing attendance
                        String updateQ = "UPDATE attendance SET status = ? WHERE att_id = ?";
                        try (PreparedStatement updateStmt = conn.prepareStatement(updateQ)) {
                            updateStmt.setString(1, status);
                            updateStmt.setInt(2, attId);
                            updateStmt.executeUpdate();
                            logAction(conn, "UPDATE", attId, "", status);
                            updatedCount++;
                        }
                    }
                }
            }
            
            conn.commit();
            JOptionPane.showMessageDialog(this, "Attendance updated successfully. Updated: " + updatedCount);
            
            loadAttendanceHistory();
            updateStatistics();
            
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                // Ignore rollback error
            }
            JOptionPane.showMessageDialog(this, "Could not update attendance: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                // Ignore
            }
        }
    }

    private void deleteAttendance() {
        int row = historyTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an attendance record to delete.");
            return;
        }
        
        int choice = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this attendance record?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
        
        if (choice != JOptionPane.YES_OPTION) return;
        
        int attId = (Integer) historyTableModel.getValueAt(row, 0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        try {
            String status = historyTableModel.getValueAt(row, 6).toString();
            logAction(conn, "DELETE", attId, status, "");
            
            String q = "DELETE FROM attendance WHERE att_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(q)) {
                stmt.setInt(1, attId);
                stmt.executeUpdate();
            }
            
            JOptionPane.showMessageDialog(this, "Attendance deleted successfully.");
            loadAttendanceHistory();
            updateStatistics();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not delete attendance: " + e.getMessage());
        }
    }

    private void resetAttendanceForm() {
        attendanceTableModel.setRowCount(0);
        studentAttendanceMap.clear();
        dateSpinner.setValue(new Date());
        if (semesterCombo.getItemCount() > 0) semesterCombo.setSelectedIndex(0);
        if (subjectCombo.getItemCount() > 0) subjectCombo.setSelectedIndex(0);
        if (sectionCombo.getItemCount() > 0) sectionCombo.setSelectedIndex(0);
        updateStatistics();
    }

    private void loadAttendanceHistory() {
        historyTableModel.setRowCount(0);
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        String q = "SELECT a.att_id, s.roll_no, u.full_name, sub.subject_code, a.semester, a.att_date, a.status " +
                   "FROM attendance a " +
                   "JOIN students s ON a.student_id = s.student_id " +
                   "JOIN users u ON s.user_id = u.user_id " +
                   "JOIN subjects sub ON a.subject_id = sub.subject_id " +
                   "ORDER BY a.att_date DESC, s.roll_no " +
                   "LIMIT 100";
        
        try (PreparedStatement stmt = conn.prepareStatement(q);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                historyTableModel.addRow(new Object[]{
                    rs.getInt("att_id"),
                    rs.getString("roll_no"),
                    rs.getString("full_name"),
                    rs.getString("subject_code"),
                    rs.getInt("semester"),
                    rs.getDate("att_date"),
                    rs.getString("status")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not load attendance history: " + e.getMessage());
        }
    }

    private void searchStudent(String rollNo) {
        if (rollNo.isEmpty()) {
            loadStudentsForAttendance();
            return;
        }
        
        for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
            String currentRoll = attendanceTableModel.getValueAt(i, 1).toString();
            if (currentRoll.equalsIgnoreCase(rollNo)) {
                attendanceTable.setRowSelectionInterval(i, i);
                attendanceTable.scrollRectToVisible(attendanceTable.getCellRect(i, 0, true));
                return;
            }
        }
        
        JOptionPane.showMessageDialog(this, "Student with Roll No " + rollNo + " not found in current list.");
    }

    private void updateStatistics() {
        int present = 0, absent = 0, late = 0, leave = 0, medical = 0;
        
        for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
            String status = attendanceTableModel.getValueAt(i, 4).toString();
            switch (status) {
                case "PRESENT": present++; break;
                case "ABSENT": absent++; break;
                case "LATE": late++; break;
                case "LEAVE": leave++; break;
                case "MEDICAL_LEAVE": medical++; break;
            }
        }
        
        int total = attendanceTableModel.getRowCount();
        double percentage = total > 0 ? (present * 100.0 / total) : 0;
        
        updateStatLabel(totalPresentLabel, String.valueOf(present));
        updateStatLabel(totalAbsentLabel, String.valueOf(absent));
        updateStatLabel(totalLateLabel, String.valueOf(late));
        updateStatLabel(totalLeaveLabel, String.valueOf(leave));
        updateStatLabel(totalMedicalLabel, String.valueOf(medical));
        updateStatLabel(attendancePercentageLabel, String.format("%.1f%%", percentage));
    }

    private void updateStatLabel(JLabel label, String value) {
        JPanel card = (JPanel) label.getParent().getComponent(0);
        JLabel valueLabel = (JLabel) card.getComponent(1);
        valueLabel.setText(value);
    }

    private void generateReport() {
        String reportType = reportTypeCombo.getSelectedItem().toString();
        Date date = (Date) reportDateSpinner.getValue();
        
        Connection conn = DBManager.getInstance().getConnection();
        if (conn == null) return;
        
        String query;
        switch (reportType) {
            case "Daily Report":
                query = "SELECT s.roll_no, u.full_name, sub.subject_code, a.status " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "JOIN subjects sub ON a.subject_id = sub.subject_id " +
                        "WHERE a.att_date = ? ORDER BY s.roll_no";
                break;
            case "Weekly Report":
                query = "SELECT s.roll_no, u.full_name, sub.subject_code, a.status, a.att_date " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "JOIN subjects sub ON a.subject_id = sub.subject_id " +
                        "WHERE a.att_date BETWEEN DATE_SUB(?, INTERVAL 7 DAY) AND ? ORDER BY a.att_date, s.roll_no";
                break;
            case "Monthly Report":
                query = "SELECT s.roll_no, u.full_name, sub.subject_code, a.status, a.att_date " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "JOIN subjects sub ON a.subject_id = sub.subject_id " +
                        "WHERE MONTH(a.att_date) = MONTH(?) AND YEAR(a.att_date) = YEAR(?) " +
                        "ORDER BY a.att_date, s.roll_no";
                break;
            case "Semester Report":
                query = "SELECT s.roll_no, u.full_name, a.semester, COUNT(*) as total_classes, " +
                        "SUM(CASE WHEN a.status = 'PRESENT' THEN 1 ELSE 0 END) as present, " +
                        "SUM(CASE WHEN a.status = 'ABSENT' THEN 1 ELSE 0 END) as absent " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "GROUP BY s.student_id, s.roll_no, u.full_name, a.semester " +
                        "ORDER BY s.roll_no";
                break;
            case "Subject Report":
                if (subjectCombo.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(this, "Please select a subject first.");
                    return;
                }
                int subjectId = Integer.parseInt(subjectCombo.getSelectedItem().toString().split(" - ")[0]);
                query = "SELECT s.roll_no, u.full_name, a.status, a.att_date " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "WHERE a.subject_id = ? ORDER BY a.att_date DESC, s.roll_no";
                break;
            case "Student Report":
                query = "SELECT s.roll_no, u.full_name, sub.subject_code, a.semester, a.att_date, a.status " +
                        "FROM attendance a " +
                        "JOIN students s ON a.student_id = s.student_id " +
                        "JOIN users u ON s.user_id = u.user_id " +
                        "JOIN subjects sub ON a.subject_id = sub.subject_id " +
                        "ORDER BY a.att_date DESC";
                break;
            default:
                query = "";
        }
        
        try {
            PreparedStatement stmt = conn.prepareStatement(query);
            
            if (reportType.equals("Daily Report")) {
                stmt.setDate(1, new java.sql.Date(date.getTime()));
            } else if (reportType.equals("Weekly Report")) {
                stmt.setDate(1, new java.sql.Date(date.getTime()));
                stmt.setDate(2, new java.sql.Date(date.getTime()));
            } else if (reportType.equals("Monthly Report")) {
                stmt.setDate(1, new java.sql.Date(date.getTime()));
                stmt.setDate(2, new java.sql.Date(date.getTime()));
            } else if (reportType.equals("Subject Report")) {
                int subjectId = Integer.parseInt(subjectCombo.getSelectedItem().toString().split(" - ")[0]);
                stmt.setInt(1, subjectId);
            }
            
            ResultSet rs = stmt.executeQuery();
            
            // Display results in history table
            historyTableModel.setRowCount(0);
            ResultSetMetaData meta = rs.getMetaData();
            
            // Update column names based on query
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                if (i <= historyTableModel.getColumnCount()) {
                    historyTableModel.setColumnIdentifiers(new String[]{"ID", "Roll No", "Student", "Subject", "Semester", "Date", "Status"});
                }
            }
            
            while (rs.next()) {
                if (reportType.equals("Semester Report")) {
                    historyTableModel.addRow(new Object[]{
                        "", rs.getString("roll_no"), rs.getString("full_name"), 
                        "Sem " + rs.getInt("semester"), 
                        rs.getInt("total_classes"), rs.getInt("present"), rs.getInt("absent")
                    });
                } else {
                    historyTableModel.addRow(new Object[]{
                        "", rs.getString("roll_no"), rs.getString("full_name"),
                        rs.getString("subject_code"),
                        rs.getInt("semester") != 0 ? rs.getInt("semester") : "",
                        rs.getDate("att_date"), rs.getString("status")
                    });
                }
            }
            
            JOptionPane.showMessageDialog(this, reportType + " generated successfully.");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not generate report: " + e.getMessage());
        }
    }

    private void exportToPdf() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("attendance_report.pdf"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(chooser.getSelectedFile()));
            document.open();
            
            document.add(new Paragraph("Attendance Report - " + reportTypeCombo.getSelectedItem()));
            document.add(new Paragraph("Generated on: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())));
            document.add(new Paragraph(" "));
            
            PdfPTable pdfTable = new PdfPTable(historyTableModel.getColumnCount());
            for (int c = 0; c < historyTableModel.getColumnCount(); c++) {
                pdfTable.addCell(historyTableModel.getColumnName(c));
            }
            
            for (int r = 0; r < historyTableModel.getRowCount(); r++) {
                for (int c = 0; c < historyTableModel.getColumnCount(); c++) {
                    Object value = historyTableModel.getValueAt(r, c);
                    pdfTable.addCell(value == null ? "" : value.toString());
                }
            }
            
            document.add(pdfTable);
            document.close();
            
            JOptionPane.showMessageDialog(this, "PDF exported successfully.");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "PDF export failed: " + e.getMessage());
        }
    }

    private void exportToExcel() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("attendance_report.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        
        try (FileWriter writer = new FileWriter(chooser.getSelectedFile())) {
            for (int c = 0; c < historyTableModel.getColumnCount(); c++) {
                writer.append(historyTableModel.getColumnName(c))
                      .append(c == historyTableModel.getColumnCount() - 1 ? "\n" : ",");
            }
            
            for (int r = 0; r < historyTableModel.getRowCount(); r++) {
                for (int c = 0; c < historyTableModel.getColumnCount(); c++) {
                    Object value = historyTableModel.getValueAt(r, c);
                    writer.append(value == null ? "" : value.toString().replace(",", " "))
                          .append(c == historyTableModel.getColumnCount() - 1 ? "\n" : ",");
                }
            }
            
            JOptionPane.showMessageDialog(this, "CSV exported successfully. Open in Excel.");
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Export failed: " + e.getMessage());
        }
    }

    private void printReport() {
        try {
            historyTable.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Print failed: " + e.getMessage());
        }
    }

    private void logAction(Connection conn, String actionType, int recordId, String oldValue, String newValue) throws SQLException {
        User user = SessionManager.getInstance().getCurrentUser();
        String q = "INSERT INTO action_log (action_type, table_name, record_id, old_value, new_value, performed_by) VALUES (?, 'attendance', ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(q)) {
            stmt.setString(1, actionType);
            stmt.setInt(2, recordId);
            stmt.setString(3, oldValue);
            stmt.setString(4, newValue);
            if (user == null) {
                stmt.setNull(5, Types.INTEGER);
            } else {
                stmt.setInt(5, user.getUserId());
            }
            stmt.executeUpdate();
        }
    }
}

package com.spas.auth;

import com.spas.models.User;
import com.spas.datastructures.UndoStack;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private UndoStack undoStack;

    private SessionManager() {
        // Initialize an undo stack for the session with a capacity of 20
        undoStack = new UndoStack(20);
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void login(User user) {
        this.currentUser = user;
        this.undoStack.clear(); // clear undo stack on new login
    }

    public void logout() {
        this.currentUser = null;
        this.undoStack.clear();
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public UndoStack getUndoStack() {
        return undoStack;
    }
}
